package com.cg.democollectionone.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.cg.democollectionone.dto.Employee;
import com.cg.democollectionone.dto.EmployeeCom;
import com.cg.democollectionone.dto.EmployeeTwo;

public class MainTwo {
	public static void main(String args[])
	{
		EmployeeTwo<Integer,Double> empone = new EmployeeTwo<Integer,Double>(1006,"ff",9999.25);
		EmployeeTwo<BigInteger,BigDecimal> emptwo = new EmployeeTwo<BigInteger,BigDecimal>(new  BigInteger("1023"),"aaaa",new BigDecimal(9999.25));
		EmployeeTwo<Integer,Double> empthree = new EmployeeTwo<Integer,Double>(1026,"assa",9999.25);
		EmployeeTwo empfour = new EmployeeTwo(1002,"dddf",9999);
		
		
		List<EmployeeTwo> mylist = new ArrayList<EmployeeTwo>();
		
	mylist.add(empone);
	mylist.add(emptwo);
	mylist.add(empthree);
	



	//	Collections.sort(mylist,new EmployeeCom());
		System.out.println(mylist);
		
		
	}

}
