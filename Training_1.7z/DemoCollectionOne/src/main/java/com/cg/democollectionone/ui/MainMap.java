package com.cg.democollectionone.ui;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import com.cg.democollectionone.dto.Employee;
import com.cg.democollectionone.dto.EmployeeCom;
import com.cg.democollectionone.dto.EmployeeTwo;

public class MainMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Map<Integer, String> mymap = new HashMap<Integer, String>();
		mymap.put(1000, "sonal");
		mymap.put(1023, "aish");
		mymap.put(1002, "yashshree");
	mymap.put(null, "yashshree");
	System.out.println(mymap.get(1000));
		//mymap.put(null, "yogfi");
		//System.out.println(mymap);
		//mymap.remove(1002);
		//System.out.println(mymap);
		//mymap.containsKey(1001);
		//System.out.println(mymap);*/
		
		//mapping using employee
		EmployeeTwo empone = new EmployeeTwo<Integer,Double>(1001,"R",1000.25);
		EmployeeTwo<Integer,Double> emptwo = new EmployeeTwo<Integer,Double>(1002,"V",2000.25);
		EmployeeTwo<Integer,Double> empthree = new EmployeeTwo<Integer,Double>(1003,"D",9000.25);
		EmployeeTwo<Integer,Double> empfour = new EmployeeTwo<Integer,Double>(1004,"A",800.25);
		
		Map<Double, EmployeeTwo> mymap = new HashMap<Double, EmployeeTwo>();
		mymap.put(0.1, empone);
		mymap.put(0.2, emptwo);
		mymap.put(0.3, empthree);
		mymap.put(0.4, empfour);
		
		/*System.out.println(mymap.get(0.1));
		System.out.println(mymap.get(0.2));
		System.out.println(mymap.get(0.3));*/
		/*System.out.println(mymap.isEmpty());
		System.out.println(mymap.keySet());
		System.out.println(mymap.containsKey(4));
		System.out.println(mymap.values());*/
		
		/*for(Double it:mymap.keySet()){
			System.out.println(mymap.get(it).getName());
			
			
		}*/
		
		/*
		
		final Set<Entry<Double, EmployeeTwo>> entries = mymap.entrySet();
		for(Entry<Double, EmployeeTwo> entry : entries)
		{ 
			System.out.println(entry.getKey() + " ==> " + entry.getValue()); 
			}

	
		TreeMap<Double, EmployeeTwo> sorted = new TreeMap<Double, EmployeeTwo>(mymap); 
		Set<Entry<Double, EmployeeTwo>> mappings = sorted.entrySet(); 
		System.out.println("HashMap after sorting by keys in ascending order "); 
		for(Entry<Double, EmployeeTwo> mapping : mappings)
		{ 
			System.out.println(mapping.getKey() + " ==> " + mapping.getValue()); 
			}

		 Comparator<Entry<Double, EmployeeTwo>> valueComparator = new Comparator<Entry<Double, EmployeeTwo>>(){
		public int compare(Entry<Double,EmployeeTwo>e1,Entry<Double,EmployeeTwo> e2) 
		{ 
			EmployeeTwo v1 = e1.getValue(); 
			EmployeeTwo v2 = e2.getValue(); 
			return v1.compareTo(v2);

			
			}
		 };
		List<Entry<Double, EmployeeTwo>> listOfEntries = new ArrayList<Entry<Double, EmployeeTwo>>(entries);
		Collections.sort(listOfEntries, valueComparator);
		LinkedHashMap<Double, EmployeeTwo> sortedByValue = new LinkedHashMap<Double, EmployeeTwo>(listOfEntries.size());
		for(Entry<Double, EmployeeTwo> entry : listOfEntries)
		{
			sortedByValue.put(entry.getKey(), entry.getValue()); } 
		System.out.println("HashMap after sorting entries by values "); 
		Set<Entry<Double, EmployeeTwo>> entrySetSortedByValue = sortedByValue.entrySet();
		for(Entry<Double, EmployeeTwo> mapping : entrySetSortedByValue)
		{
			System.out.println(mapping.getKey() + " ==> " + mapping.getValue()); }

		
		*/
	
      /*   Set set = mymap.entrySet();
         Iterator iterator = set.iterator();
         while(iterator.hasNext()) {
               Map.Entry me = (Map.Entry)iterator.next();
               System.out.print(me.getKey() + ": ");
               System.out.println(me.getValue());*/
       
         
         
         Collection<EmployeeTwo> mycollection=mymap.values();
         List< EmployeeTwo> listOfEntries = new ArrayList<EmployeeTwo>(mycollection);
        Collections.sort(listOfEntries, new EmployeeCom());
        for(EmployeeTwo employee:listOfEntries) {
         System.out.println(""+employee.getName());
        }
         
        
         
         
         
         
	}	

        
         
         }
		
		
		
		
	
		
		
		
		
		
		
		
		
		
		
		
		


