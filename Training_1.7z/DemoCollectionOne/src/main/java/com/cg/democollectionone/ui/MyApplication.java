package com.cg.democollectionone.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.cg.democollectionone.dto.Employee;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
	/*	A a = new A();
		System.out.println("GHiiiiiiiiiiii");
		a.getAll();*/
	/*	
		String str="Capgemini";
		String str1="Capgemini";
		Integer i=10;
		Integer j=0;
		System.out.println(i.hashCode()+""+j.hashCode());
		System.out.println(i.equals(j));
		//System.out.println( str.hashCode()+""+str1.hashCode());
		//System.out.println(str.equals(str1));*/
		
		
		//Set
		//Hashset
	/*	
		Employee emp = new Employee(40,"A",70.50);
		Employee empone = new Employee(20,"B",30.50);
		Employee emptwo = new Employee(30,"C",40.50);
		
		Set<Employee> myset = new HashSet<Employee>();
		myset.add(emp);
		myset.add(empone);
		myset.add(emptwo);*/
	
	/*	List<Employee> sortedList = new ArrayList<Employee>(myset);
		Collections.sort(sortedList);
		
		System.out.println(sortedList);*/
			Set<String> myset1 = new HashSet<String>();
		myset1.add("S");
		myset1.add("A");
		myset1.add("Y");
		myset1.add("R");
		System.out.println(myset1);
		
	//Set<String> my = new TreeSet<String>();
	/*Set my = new TreeSet();
		my.add("S");
		my.add("A");
		my.add("Y");
		my.add("5");
		my.add("F");
		my.add("8");*/
	
		//System.out.println(myset);
		
		//Treeset
	/*	Employee emp = new Employee(40,"R",20.50);
		Employee empone = new Employee(20,"a",25.50);
		Employee emptwo = new Employee(30,"A",26.50);
		
		Set<Employee> myset = new TreeSet<Employee>();
		myset.add(emp);
		myset.add(empone);
		myset.add(emptwo);
		
		System.out.println(myset);*/
		
	
		
	}

}
/*
class A{
	
	
	public void  getAll() {
		System.out.println("Welcome");
		
	}
	
}*/
