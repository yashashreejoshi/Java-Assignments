package com.cg.demotwo.ui;

import java.math.BigDecimal;

import com.cg.demotwo.dto.Employee;

public class MyTest {
	static double salary=1000;
	
	public static void main(String[] args) {
		//MyTest emp = new MyTest();
		//System.out.println(salary);
		//getAllData();
		System.out.println("In main");
		A.getAll();
		/*Employee.pf=1200;
		Employee emp = new Employee(10001, "ABC", new BigDecimal(10000.0), 0.1);
		System.out.println("Employee Id "+ emp.getEmpId());
		System.out.println("Employee Salaary " +emp.takeHomeSalary());
		System.out.println("Employee Name " + emp.getFullName());
		System.out.println(Employee.pf);
		
		Employee empOne = new Employee(10001, "Pooja", new BigDecimal(12000.0), 0.2);
		
		System.out.println("Employee Id "+ empOne.getEmpId());
		System.out.println("Employee Salaary " +empOne.takeHomeSalary());
		System.out.println("Employee Name " + empOne.getFullName());
		System.out.println(Employee.pf);*/
	}
	static {
		System.out.println("static in my test");
	}

}

class A {
	static {
		System.out.println("In A static block");
	}
	
	public static void getAll() {
		System.out.println("in a static method");
		
	}
}


