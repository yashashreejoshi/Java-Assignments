package com.cg.jpademo.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.OneToMany;

@Entity
public class Department {

	public Department(int id, String name, List<Employee> myEmployeeList) {
		super();
		this.id = id;
		this.name = name;
		this.myEmployeeList = myEmployeeList;
	}
	public Department() {
		super();
	}
	
	@Id
	@Column(name="dept_id")
	private int id;
	@Column(name="dept_name")
	private String name;
	@OneToMany(mappedBy="dep")
	private List<Employee> myEmployeeList = new ArrayList<Employee>();
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public List<Employee> getMyEmployeeList() {
		return myEmployeeList;
	}
	public void setMyEmployeeList(List<Employee> myEmployeeList) {
		this.myEmployeeList = myEmployeeList;
	}
	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + ", myEmployeeList=" + myEmployeeList + "]";
	}
}
