package com.cg.jpademo.ui;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpademo.dto.Address;
import com.cg.jpademo.dto.Department;
import com.cg.jpademo.dto.Employee;

public class MyApplication {

	public static void main(String[] args) {
		 EntityManagerFactory emf=Persistence.createEntityManagerFactory("demoemployeemanagement");  
	        EntityManager em=emf.createEntityManager();  
	          
	em.getTransaction().begin();  
	          
	       Address addr = new Address();
	       addr.setCity("pune");
	       addr.setStreet("paud road");
	       addr.setPincode(56367);
	       
	       Department dep = new Department();
	       dep.setId(62);
	       dep.setName("php");
	       Department depOne = new Department();
	       depOne.setId(2962);
	       depOne.setName(".net");
		   Employee s1=new Employee();  
	       Employee s2= new Employee();
	       Employee s3= new Employee();
	       s1.setId(7998);  
	        s1.setName("rutuja");  
	        s1.setSalary(5877);					//insertion
	        s1.setType(true);
	        s1.setDoj(new Date());
	        s1.setAddr(addr);
	        s1.setDep(dep);
	       
	        
	        s2.setId(8998);  
	        s2.setName("radhika");  
	        s2.setSalary(4557);
	        s2.setType(true);
	        s2.setDoj(new Date());
	        s2.setAddr(addr);
	        s2.setDep(dep);
	        
	        s3.setId(10998);  
	        s3.setName("rutu");  
	        s3.setSalary(357);					//insertion
	        s3.setType(true);
	        s3.setDoj(new Date());
	        s3.setAddr(addr);
	        s3.setDep(depOne);
	        
	        dep.getMyEmployeeList().add(s1);
	        dep.getMyEmployeeList().add(s2);
	        dep.getMyEmployeeList().add(s3);
	        
	        List<Employee> myList = new ArrayList<Employee>();
	        myList.add(s1);
	        myList.add(s2);
	        myList.add(s3);
	        dep.setMyEmployeeList(myList);
	        
	        //s2.setDept(dep);
	        em.persist(dep);
	        em.persist(depOne);
	     /*  em.persist(s1); 
	        em.persist(s2);
	        em.persist(s3);
	       */
	        
	       
	        
	        
	        
	        
	        /*Employee s=em.find(Employee.class,11);  		//find
	        System.out.println("Employee id = "+s.getId());  
	        System.out.println("Employee Name = "+s.getName());  
	        System.out.println("Employee Salary = "+s.getSalary());  
	        System.out.println("Employee Salary = "+s.getDoj());  
	        */
	        
	        
	      /* // Employee update=em.find(Employee.class,11);  
	        System.out.println("Before Updation");  
	        System.out.println("Student id = "+s.getId());  
	        System.out.println("Student Name = "+s.getName());  
	        System.out.println("Student Age = "+s.getSalary());  
	          
	s.setName("Yashashree");  			//update
	          
	        System.out.println("After Updation");  
	        System.out.println("Student id = "+s.getId());  
	        System.out.println("Student Name = "+s.getName());  
	        System.out.println("Student Age = "+s.getSalary());  
	          
	        
	        em.remove(s);*/
	      em.getTransaction().commit();  
	          
	        //emf.close();  
	       em.close();  

	}

}
