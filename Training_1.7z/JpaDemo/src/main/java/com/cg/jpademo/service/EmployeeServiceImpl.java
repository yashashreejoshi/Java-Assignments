package com.cg.jpademo.service;

import java.util.List;

import com.cg.jpademo.dao.EmployeeDao;
import com.cg.jpademo.dao.EmployeeDaoImpl;
import com.cg.jpademo.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDao dao;
	public EmployeeServiceImpl() {
		dao=new EmployeeDaoImpl();
	}
	public void addEmployee(Employee e) {
		// TODO Auto-generated method stub
		dao.save(e);
		
	}

	public List<Employee> searchBySalary(double low, double higher) {
		// TODO Auto-generated method stub
		return dao.findBySalary(low, higher);
	}

	public List<Employee> searchByDepartmentName(String name) {
		// TODO Auto-generated method stub
		return dao.findByDepartmentName(name);
	}

}
