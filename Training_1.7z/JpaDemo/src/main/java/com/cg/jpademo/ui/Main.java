package com.cg.jpademo.ui;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.jpademo.dto.Address;
import com.cg.jpademo.dto.Department;
import com.cg.jpademo.dto.Employee;
import com.cg.jpademo.service.EmployeeService;
import com.cg.jpademo.service.EmployeeServiceImpl;

public class Main {
	static EmployeeService service;
	public static void main(String[] args) {
		service = new EmployeeServiceImpl();
		Scanner scr = new Scanner(System.in);
		int ch;
		System.out.println("Enter employee id");
		int emp_id=scr.nextInt();
		System.out.println("Enter employee name");
		String emp_name = scr.next();
		System.out.println("Enter employee salary");
		double emp_salary=scr.nextDouble();
		boolean type=true;
		System.out.println("Enter employee date of joining");
		String date = scr.next();
		
		System.out.println("Enter dept id");
		int dep_id = scr.nextInt();
		
		System.out.println("Enter dept_name");
		String name = scr.next();
		
		Department dep = new Department();
		dep.setId(dep_id);
		dep.setName(name);
		
		Employee emp = new Employee();
		emp.setId(emp_id);
		emp.setName(emp_name);
		emp.setSalary(emp_salary);
		Address add = new Address("nagar","maha",102);
		emp.setAddr(add);
		emp.setDoj(new Date());
		emp.setDep(dep);
		emp.setType(type);
		//service.addEmployee(emp);
		//List<Employee> myList=service.searchBySalary(2000, 3000);
		List<Employee> myList=service.searchByDepartmentName("java");
		for(Employee employee: myList) {
			System.out.println("Employee Id"+employee.getId());
			System.out.println("Employee Name" + employee.getSalary());
			System.out.println("Employee Name" + employee.getDep().getName());
			
		}
	}

}
