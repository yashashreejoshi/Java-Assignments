package com.cg.jpademo.dto;

import java.sql.Time;
import java.util.Date;
import java.util.Timer;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="empdb")
public class Employee {

public Employee() {
		
	}

	public Employee(int id, String name, double salary, boolean type, Date doj, Address addr, Department dep) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.type = type;
		this.doj = doj;
		this.addr = addr;
		this.dep = dep;
	}

	@Id
	@Column(name="emp_id")
	private int id;
	@Column(name="emp_name")
	private String name;
	@Column(name="emp_salary")
	private double salary;
	@Column(name="emp_type")
	private boolean type;
	@Column(name="joining")
	private Date doj;
	@Embedded
	private Address addr;
	
	@ManyToOne(cascade =CascadeType.ALL)
	@JoinColumn(name="dep_id")
	private Department dep;
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public boolean isType() {
		return type;
	}

	public void setType(boolean type) {
		this.type = type;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}


	public Address getAddr() {
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	public Department getDep() {
		return dep;
	}

	public void setDep(Department dep) {
		this.dep = dep;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", type=" + type + ", doj=" + doj
				+ ", addr=" + addr + ", dep=" + dep + "]";
	}

	

	

	
	
}
