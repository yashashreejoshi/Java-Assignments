package com.cg.jpademo.dto;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class EmployeeService {
	
	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("myPROJECT");
	private EntityManager em = emf.createEntityManager();
	private EntityTransaction tx = em.getTransaction();

	public Employee createEmployee(int id, String name, double salary, boolean type) {
		Employee employee = new Employee();
		employee.setId(id);
		employee.setName(name);
		employee.setSalary(salary);
		employee.setType(type);
		tx.begin();
		em.persist(employee);
		tx.commit();
		return employee;
		
	}
}
