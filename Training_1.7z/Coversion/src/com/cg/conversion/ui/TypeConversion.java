package com.cg.conversion.ui;

public class TypeConversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float floatVal = 1.0f;
		double doubleVal = 4.0d;
		byte byteVal = 7;
		short shortVal = 7;
		long longVal = 5;
		
		short result1 = (short)longVal;
		short result2 = (short) (byteVal - longVal);
		float result3 = longVal - floatVal;
		long result4 = (long)(shortVal - longVal + floatVal);
		System.out.println("Success");
		

	}

}
