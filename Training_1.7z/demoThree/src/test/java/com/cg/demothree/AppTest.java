package com.cg.demothree;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
	 
	 @Before
	 void dobeforeMyTest(){
	 System.out.println("before test");
	 }
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
	
	@After
	@After
	void doafterMyTest() {
	System.out.print.ln("After test");
	}
}
