package com.cg.collections.service;

import java.util.List;

import com.cg.collections.dto.Employee;

public interface EmployeeService {


	public void addemp(Employee emp);
	
	public List<Employee> searchName(String Name);
	
	public List<Employee> showall();
	
	public Employee update(Employee emp);
	
	public void sort();

	
	public Employee searchid(int id);
}
