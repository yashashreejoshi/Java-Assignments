package com.cg.collections.dao;

import java.util.List;

import com.cg.collections.dto.Employee;
import com.cg.collections.exe.EmployeeExe;

public interface EmployeeDaoo {

		public Employee save(Employee emp);
		public List<Employee> findByName(String name);
		
		public Employee findById(int id) throws EmployeeExe;
		public List<Employee> showall();
		
	}

