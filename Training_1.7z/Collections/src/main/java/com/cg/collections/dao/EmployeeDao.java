package com.cg.collections.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.collections.dto.Employee;
import com.cg.collections.exe.EmployeeExe;
import com.cg.collections.util.DbUtil;

public class EmployeeDao implements EmployeeDaoo {

	public Employee save(Employee emp) {
		Connection con = DbUtil.getConnection();
		String query_insert="INSERT INTO employeee VALUES(?,?,?)";
		PreparedStatement pstmt=null;
		try {
			pstmt = con.prepareStatement(query_insert);
			pstmt.setInt(1, emp.getId());
			pstmt.setString(2, emp.getName());
			pstmt.setDouble(3, emp.getSalary());
			
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new EmployeeExe("CONNECTION NOT CLOSED");
			}
		}
		
		return null;
	}

	public List<Employee> findByName(String name) {
		return null;
	}

	public Employee findById(int id) throws EmployeeExe {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> showall() {
		Connection con = DbUtil.getConnection();
		String query_show="SELECT EMP_ID,EMP_NAME,EMP_SALARY FROM EMPLOYEEE";
		PreparedStatement pstmt=null;
		List<Employee> myList=new ArrayList<Employee>();;
		try {
			 
			pstmt=con.prepareStatement(query_show);
			ResultSet result = pstmt.executeQuery();
			
			while(result.next()) {
				Employee emp = new Employee();
				emp.setId(result.getInt("emp_id"));
				emp.setName(result.getString("emp_name"));
				emp.setSalary(result.getDouble("emp_salary"));
				myList.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new EmployeeExe("CONNECTION NOT CLOSED");
			}
		
		return myList;
	}

	/*List<Employee> empdata;
	public EmployeeDao()
	{
		empdata=new ArrayList<Employee>();
	}

	public Employee save(Employee emp) {
		// TODO Auto-generated method stub
		
	
		empdata.add(emp);
		return emp;
	}

	public List<Employee> findByName(String name) {
		// TODO Auto-generated method stub
		
		List<Employee> empsearch=new ArrayList<Employee>();
		for (Employee empp : empdata) {
	        if (empp.getName().equals(name)) {
	           empsearch.add(empp);
	        }
	    }
		return empsearch;
	}

	public Employee findById(int id) throws EmployeeExe {
		
		
	
		for (Employee employee : empdata) {
	     
			if (employee.getId()==id)
		{
	           return employee;
	    }else
	    {
	    	
	    	throw new EmployeeExe("id not found");
	    }
	        
	
		}
		return null;
		
	}

	public List<Employee> showall() {
		// TODO Auto-generated method stub
		return empdata;
	}
*/
}
}


