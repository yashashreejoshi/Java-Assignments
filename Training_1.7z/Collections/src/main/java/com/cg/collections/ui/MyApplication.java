package com.cg.collections.ui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class MyApplication {

	public static void main(String[] args) {
	
		/*String driver=null ,url= null ,uname = null, passwd=null;
		try {
			try {
				InputStream it = new FileInputStream("src/main/resources/jdbc.properties");
				Properties prop = new Properties();
				prop.load(it);
				driver=prop.getProperty("jdbc.driver");
				url=prop.getProperty("jdbc.url");
				uname=prop.getProperty("jdbc.username");
				passwd=prop.getProperty("jdbc.password");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

	Class.forName(driver);

Connection con=	DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "Capgemini123");
PreparedStatement pst=con.prepareStatement("INSERT INTO EMPLOYEE VALUE(?,?,?)");
Scanner s=new Scanner(System.in);
System.out.println("***INSERT RECORD***");
System.out.println("enter id");
int id=s.nextInt();
System.out.println("enter name");
String name=s.next();
System.out.println("enter sal");
double sal=s.nextDouble();

pst.setInt(1, id);
pst.setString(2, name);
pst.setDouble(3, sal);
pst.executeUpdate();

PreparedStatement pst1=con.prepareStatement("UPDATE EMPLOYEE SET EMP_SALARY= ? WHERE EMP_ID=?");
System.out.println("***UPDATE RECORD***");
System.out.println("enter id");
int id1=s.nextInt();
System.out.println("enter sal to update");
double sal1=s.nextDouble();

pst1.setDouble(1, sal1);
pst1.setInt(2, id1);
pst1.executeUpdate();

PreparedStatement pst2=con.prepareStatement("DELETE FROM EMPLOYEE WHERE EMP_ID=?");
System.out.println("***DELETE RECORD***");
System.out.println("enter id");
int id2=s.nextInt();

pst2.setInt(1, id2);
pst2.executeUpdate();


PreparedStatement pst3=con.prepareStatement("SELECT * FROM EMPLOYEE");
System.out.println("***SHOW RECORD***");
System.out.println("enter id");

ResultSet rs = pst3.executeQuery();
System.out.println("SHOW DETAILS");
while(rs.next())
{
	System.out.println(rs.getInt(1)+ " " + rs.getString(2)+ " " + rs.getDouble(3));

}
;System.out.println("conncetion done");
	} catch (ClassNotFoundException e) {
		System.out.println("driver not loaded");
		}
		catch (SQLException e) {
			System.out.println("conncetion not done");
		} 

	}*/

}}




