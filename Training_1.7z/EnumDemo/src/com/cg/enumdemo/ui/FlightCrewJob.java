package com.cg.enumdemo.ui;

public enum FlightCrewJob {
	Pilot,
	CoPilot,
	FlightAttendant,
	AirMarshal
}
