package com.cg.enumdemo.ui;

public class CrewMember {
	
	public CrewMember() {
		// TODO Auto-generated constructor stub
	}

	private FlightCrewJob job;
	
	public CrewMember(FlightCrewJob job) {
		this.job=job;
	}
	
	public void setJob(FlightCrewJob job) {
		this.job=job;
	}
}
