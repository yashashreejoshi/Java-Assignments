package com.cg.enumdemo.ui;

public class Main {

	public static void main(String[] args) {
		CrewMember judy =  new CrewMember(FlightCrewJob.CoPilot);
		
		judy.setJob(FlightCrewJob.Pilot);

	}

}
