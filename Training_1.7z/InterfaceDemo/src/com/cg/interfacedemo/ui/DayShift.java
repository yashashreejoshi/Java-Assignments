package com.cg.interfacedemo.ui;

public class DayShift implements AbstractEg {

	//@Override
	public void getlogin() {
		// TODO Auto-generated method stub
		
	}

	//@Override
	public void getLogOut() {
		// TODO Auto-generated method stub
		
	}

	//@Override
	public void getCompany() {
		// TODO Auto-generated method stub
		
	}

}
