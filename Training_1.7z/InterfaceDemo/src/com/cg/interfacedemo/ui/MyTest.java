package com.cg.interfacedemo.ui;

public class MyTest {

	public static void main(String[] args) {
		AbstractEg temp = new DayShift();
		System.out.println(temp.time);
		temp.getlogin();
		temp.getLogOut();
		temp.getCompany();

	}

}
