package com.cg.interfacedemo.ui;

public interface AbstractEg {
	
	double time=9.5;  //static and final
	public void getlogin();  //public abstract void getlogin();
	public void getLogOut();
	public void getCompany();
}
