package com.cg.exceptiondemo.ui;

public class MyException {
	public static void main(String[] args) {
		int i = 12;
		int j = 0;
		try {
			int result = i / (j-2);
			System.out.println(result);
		}catch(Exception e) {
			System.out.println("Errorr" + e);
			//e.printStackTrace();
		}
	}

}
