package com.cg.exceptiondemo.ui;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;;

public class MyApplication {
	public static void main(String args[]) {
		try {
			new ClassB().getAll();
		}catch(ArithmeticException e) {
			System.out.println("divide by zero");
		}
		
	
}
}
