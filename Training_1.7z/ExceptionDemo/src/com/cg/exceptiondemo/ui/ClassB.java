package com.cg.exceptiondemo.ui;

public class ClassB {

	//public void getAll(){
		public void getAll(int salary) {
			if(salary < 5000) {
				throw new EmployeeException("shoulf be greater than 5000");
	}
			System.out.println(salary);
		}
		
		//int a =10;
		//int b=0;
		//if(b==0) {
			//throw new ArithmeticException("GHGGHUI");
		//}
		//System.out.println("Result" + a/b);
	//}
		/*int c[]= {10,22,33};
		try {
			System.out.println(a/b);
			System.out.println(c[9]);
		}catch(ArithmeticException e) {
			System.out.println("Check second number");
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Check arary");
		}finally {
			System.out.println("Always");
		}
		System.out.println("Hi");
	}*/
		/*int a[] = {10,3,6};
		try {
			System.out.println(a[6]);
		}catch(NullPointerException e) {
			System.out.println("Check Array");     
		}finally {
			System.out.println("Always");
		}
		System.out.println("In B...");
	}*/
}
