package com.cg.exceptiondemo.ui;

public class Main {

	public static void main(String[] args) {
		try {
			new ClassB().getAll(6000);
		}catch(EmployeeException e) {
			System.out.println(e.getMessage());
		}
	}

}
