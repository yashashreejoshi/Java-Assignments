package com.cg.productmanagementdemo.dao;

import java.util.List;


import com.cg.productmanagementdemo.dto.Product;



public interface ProductDao {
	public Product save(Product product);
	public List<Product> findByPrice(double minprice,double maxprice)throws ProductException;
	public Product findById(int id)throws ProductException;
	public List<Product> showAll();

}
