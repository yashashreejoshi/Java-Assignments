package com.cg.productmanagementdemo.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.productmanagementdemo.dto.Product;


public class ProductDaoImpl implements ProductDao {
	final static  double max_price=5000;
	final static  double min_price=1000;
	List<Product> productdata;
	
	public ProductDaoImpl(){
		productdata= new ArrayList<Product>();
	}
	
	
	@Override
	public Product save(Product product) {
		// TODO Auto-generated method stub
		
		productdata.add(product);
		return product;
	}

	@Override
	public List<Product> findByPrice(double minprice,double maxprice) throws ProductException {
		// TODO Auto-generated method stub
		List<Product> prosearch= new ArrayList<>();
		for(Product pro: productdata)
		{
			if(pro.getPrice() <= max_price&& pro.getPrice()>=min_price)
			{
				prosearch.add(pro);
			
			}
			
		
		}
		if(prosearch.isEmpty()) {
			throw new ProductException("no products found");
		}
		return prosearch;
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		
		return productdata;
	}


	@Override
	public Product findById(int id) throws ProductException {
		// TODO Auto-generated method stub
		
		
		for(Product product:productdata)
		{
			if(product.getId()==id)
			{
				return product;
			}else {
				throw new ProductException("Id not found");
			}
		
		}
		return null;
	}

}
