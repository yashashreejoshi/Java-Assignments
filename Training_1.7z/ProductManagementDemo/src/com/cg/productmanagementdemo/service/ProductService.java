package com.cg.productmanagementdemo.service;

import java.util.List;

import com.cg.productmanagementdemo.dao.ProductException;
import com.cg.productmanagementdemo.dto.Product;

public interface ProductService {
	
	
	public void addProduct(Product product);
	public List<Product> searchByPrice(double minprice,double maxprice)throws ProductException;
	public Product findById(int id)throws ProductException;
	public Product update(Product product);
	public boolean removeProduct(Product product);
	public List<Product> showAll();
	public void  sort();
	
	

}
