package com.cg.productmanagementdemo.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.cg.productmanagementdemo.dao.ProductDaoImpl;
import com.cg.productmanagementdemo.dao.ProductException;
import com.cg.productmanagementdemo.dto.Product;

public class ProductServiceImpl implements ProductService{
	
	
	
	
	ProductDaoImpl dao;
	Product product;
	public ProductServiceImpl(){
		dao=new ProductDaoImpl();
		
	}

	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		
		
		dao.save(product);
		
		
	}

	@Override
	public List<Product> searchByPrice(double minprice,double maxprice)throws ProductException {
		// TODO Auto-generated method stub
		return dao.findByPrice(minprice,maxprice);
	
	}

	@Override
	public Product update(Product product) {
		// TODO Auto-generated method stub
		return dao.save(product);
	}

	@Override
	public boolean removeProduct(Product product) {
		
		// TODO Auto-generated method stub
		List<Product> pro = new ArrayList<>();
		
		return false;
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	@Override
	public void sort() {
		// TODO Auto-generated method stub
		List<Product> mylist = new ArrayList<Product>();
				mylist=dao.showAll();
		Collections.sort( mylist);
		System.out.println(mylist);
		
	}

	@Override
	public Product findById(int id)throws ProductException {
		// TODO Auto-generated method stub
		 return dao.findById(id);
	}

}
