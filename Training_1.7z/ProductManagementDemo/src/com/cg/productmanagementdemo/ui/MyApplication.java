package com.cg.productmanagementdemo.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


import com.cg.productmanagementdemo.dao.ProductException;
import com.cg.productmanagementdemo.dto.Product;
import com.cg.productmanagementdemo.service.ProductServiceImpl;

public class MyApplication {

	private static ProductServiceImpl service;
	public static void main(String[] args) throws ProductException {
		// TODO Auto-generated method stub
		service=new ProductServiceImpl();
		Scanner scr = new Scanner(System.in);
		int ch;
		do {
		print();
		System.out.println("Enter your choice");
		 ch=scr.nextInt();
		
		switch(ch) {
		case 1:
			System.out.println("enter product id");
			int id= scr.nextInt();
			System.out.println("enter product name");
			String name= scr.next();
			System.out.println("enter product price");
			double price= scr.nextDouble();
			System.out.println("enter product description");
			String desc = scr.next();
			
			Product product = new Product();
			product.setId(id);
			product.setName(name);
			product.setPrice(price);
			product.setDescription(desc);
			service.addProduct(product);
			
			break;
		case 2:
			List<Product> mylist=service.showAll();
			for(Product productdata:mylist) {
				System.out.println("Product id is:--\t"+productdata.getId());
				System.out.println("Product name is:--\t"+productdata.getName());
				System.out.println("ProductPrice is:--\t"+productdata.getPrice());
				System.out.println("Product description------"+productdata.getDescription());
				
			}
			break;
		case 3:
			System.out.println("Enter the Product id");
			int pid=scr.nextInt();
			Product productSearch=service.findById(pid);
		
				System.out.println("id is"+productSearch.getId());
			
			break;
		case 4:
			final   double max_price=5000;
			final  double min_price=1000;
			List<Product> prosearch = service.searchByPrice(min_price,max_price);
			for(Product proall:prosearch) {
				System.out.println("price is"+proall.getPrice());}
		
			break;
		case 5:
			System.out.println("Enter the Employee id");
			int productid=scr.nextInt();
			
			Product pro2=service.findById(productid);
			if(pro2!=null)
			{
				System.out.println(pro2);}
			
			
		
			break;
			
		
		case 6:
			System.out.println("Enter the Employee id");
			int pid1=scr.nextInt();
			try {
			Product pro1=service.findById(pid1);
		
			if(pro1!=null)
			{
				System.out.println(pro1);
				System.out.println("enter price");
				double newprice = scr.nextDouble();
				pro1.setPrice(newprice);
				service.update(pro1);
			}
			
			
			}catch(ProductException e) {
				System.out.println(e.getMessage());
				
			}
			
			break;
			
		case 7:
			service.sort();
			break;
		}
		
		
		
		}while(ch<8);

	}
	public static void print() {
		
		
	
		System.out.println("1.Add Product");
		System.out.println("2.show product");
		System.out.println("3.Search Product by id");
		System.out.println("4.Search Product by price");
		System.out.println("5.remove Product");
		System.out.println("6.update Product");
		System.out.println("7.sort");
	
		
		
	}

}
