package com.cg.stringdemo.ui;

public class CompareString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer i1A = new Integer(10);
		Integer i2B = new Integer(10);
		System.out.println(i1A.hashCode());
		System.out.println(i2B.hashCode());
		
		if(i1A == i2B) {
			System.out.println("Equal");
		}
		
		if(i1A.equals(i2B)) {
			System.out.println("hi Equal");
		}
		
		Integer a = 4*2;
		Integer b = 2*2*2;
		System.out.println(a.hashCode());
		System.out.println(b.hashCode());
		if(a == b) {
			System.out.println("ok");
		}
	}

}
