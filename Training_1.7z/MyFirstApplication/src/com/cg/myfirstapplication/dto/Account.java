package com.cg.myfirstapplication.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

public class Account {
	private BigInteger accountId;
	private BigDecimal balance;
	private Transaction trans;

}
