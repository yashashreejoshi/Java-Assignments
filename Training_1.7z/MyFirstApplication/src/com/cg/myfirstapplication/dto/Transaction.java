package com.cg.myfirstapplication.dto;

import java.math.BigDecimal;
import java.util.Date;

public class Transaction {
	private int tranId;
	private String description;
	private Date date;
	private BigDecimal amount;
	private BigDecimal balance;

}
