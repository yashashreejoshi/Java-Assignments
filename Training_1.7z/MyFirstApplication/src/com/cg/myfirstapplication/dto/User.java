package com.cg.myfirstapplication.dto;

public class User {
		private String name;
		private String email;
		private String password;
		private Address addr;
		private Account acc;

	}

