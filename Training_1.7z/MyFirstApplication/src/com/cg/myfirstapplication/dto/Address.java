package com.cg.myfirstapplication.dto;

public class Address {
	private String state;
	private String city;
	private int pincode;

}
