package com.cg.myfirstapplication.services;

import com.cg.myfirstapplication.dto.User;

public interface IPaymentWallet {
	public User createRegisteration(User user);
	public User login(User user);

}
