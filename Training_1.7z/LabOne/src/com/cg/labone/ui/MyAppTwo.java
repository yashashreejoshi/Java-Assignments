package com.cg.labone.ui;

import java.util.Scanner;

public class MyAppTwo {
	
	public int calculateDifference(int n) {
		int sum=0, sum1=0, prod2=1;
		for(int i = 1; i<=n; i++) {
			int prod = i*i;
			sum = sum + prod;
			
			sum1=sum1+i;
			prod2 = sum1*sum1;
		}
		int result = sum-prod2;
		return result;
	}

	public static void main(String[] args) {
		MyAppTwo app = new MyAppTwo();
		Scanner in = new Scanner(System.in);
		System.out.println("Enter numbeer ");
		int n = in.nextInt();
		System.out.println(app.calculateDifference(n));
		
	}

}
