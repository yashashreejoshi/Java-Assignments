package com.cg.labone.ui;

import java.util.Scanner;

public class MyApp {
	
	public int calculateSum(int n) {
		int sum=0;
		for(int i = 0; i<n; i++) {
			if(i%3==0 || i%5==0) {
				sum=sum+i;
			}
		}
		return sum;
	}

	public static void main(String[] args) {
		MyApp app = new MyApp();
		Scanner scr = new Scanner(System.in);
		System.out.println("enter n");
		int n = scr.nextInt();
		int z = app.calculateSum(n);
		System.out.println(z);

	}

}
