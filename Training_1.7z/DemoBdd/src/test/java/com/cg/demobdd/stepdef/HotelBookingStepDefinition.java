package com.cg.demobdd.stepdef;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookingStepDefinition {

	WebDriver driver;
	By firstName;
	By lastName; 
	By email;
	By button;
	@Before
	public void init() {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Training\\DemoBdd\\MyDriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
	}
	
	@After
	public void afterAll() throws InterruptedException {
		Thread.sleep(5000);
			driver.quit();
	}
	@Given("^Hotel Booking HTML Page is given$")
	public void hotel_Booking_HTML_Page_is_given()  {
	    // Write code here that turns the phrase above into concrete actions
	    driver.get("D:\\Training\\DemoBdd\\MyPage\\hotelbooking.html");
	    firstName=By.xpath("//*[@id=\"txtFirstName\"]");
		lastName=By.xpath("//*[@id=\"txtLastName\"]");
		email=By.id("txtEmail");
		button=By.xpath("//*[@id=\"btnPayment\"]");
	}

	@When("^clicking on submit button for first name validation$")
	public void clicking_on_submit_button_for_first_name_validation()  {
	    // Write code here that turns the phrase above into concrete actions
	driver.findElement(button).click();
	}

	@Then("^alert is coming 'Please fill the first name'$")
	public void alert_is_coming_Please_fill_the_first_name() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		String actualData=driver.switchTo().alert().getText();
		String expectedData="Please fill the First Name";
		assertEquals(expectedData, actualData);
		Thread.sleep(5000);
	}

	@When("^clicking on submit button for last name validation$")
	public void clicking_on_submit_button_for_last_name_validation() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
 
		   driver.switchTo().alert().dismiss();
		   driver.findElement(firstName).sendKeys("yasha");;
		   driver.findElement(button).click(); 
		   Thread.sleep(5000);
		    

	}

	@Then("^alert is coming 'Please fill the last name'$")
	public void alert_is_coming_Please_fill_the_last_name() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		String actualData=driver.switchTo().alert().getText();
		String expectedData="Please fill the Last Name";
		assertEquals(expectedData, actualData);
		Thread.sleep(5000);
	}

	@When("^clicking on submit button for email validation$")
	public void clicking_on_submit_button_for_email_validation() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		   driver.findElement(lastName).sendKeys("joshi");
		   driver.findElement(button).click(); 
		   Thread.sleep(5000);
	}

	@Then("^alert is coming 'Please fill the email'$")
	public void alert_is_coming_Please_fill_the_email() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		String actualData=driver.switchTo().alert().getText();
		String expectedData="Please fill the Email";
		assertEquals(expectedData, actualData);
		Thread.sleep(5000);
	}

	@When("^clicking on submit button for mobile validation$")
	public void clicking_on_submit_button_for_mobile_validation() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		   driver.findElement(email).sendKeys("yashuj2gmail.com");
		   driver.findElement(button).click(); 
		   Thread.sleep(5000);
	}

	@Then("^alert is coming 'Please fill the mobile no'$")
	public void alert_is_coming_Please_fill_the_mobile_no() {
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@When("^clicking on submit button for address validation$")
	public void clicking_on_submit_button_for_address_validation() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^alert is coming 'Please fill the address'$")
	public void alert_is_coming_Please_fill_the_address() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^clicking on submit button for city validation$")
	public void clicking_on_submit_button_for_city_validation()  {
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@Then("^alert is coming 'Please select the city'$")
	public void alert_is_coming_Please_select_the_city() {
	    // Write code here that turns the phrase above into concrete actions
	
	}

	@When("^clicking on submit button for state validation$")
	public void clicking_on_submit_button_for_state_validation() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^alert is coming 'Please select the state'$")
	public void alert_is_coming_Please_select_the_state() {
	    // Write code here that turns the phrase above into concrete actions
	
	}


}
