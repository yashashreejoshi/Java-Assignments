package com.cg.calcengineusingmethodoverloading.ui;

import com.cg.calcengineusingmethodoverloading.dto.MathEquation;

public class MyApp {

	public static void main(String[] args) {
		MathEquation[] equations = new MathEquation[4];
		equations[0] = new MathEquation('a', 100.0d, 50.0d);
		equations[1] = new MathEquation('s', 11.0d, 5.9d);
		equations[2] = new MathEquation('m', 20.0d, 3.0d);
		equations[3] = new MathEquation('d', 64.0d, 8.0d);
		
		for(MathEquation equation : equations) {
			equation.execute();
			System.out.println("results = ");
			System.out.println(equation.getResult());
		}
		System.out.println();
		System.out.println("Using ovewrloads...");
		System.out.println();
		
		double leftDouble = 9.0d;
		double rightDouble = 4.0d;
		
		MathEquation equ = new MathEquation('d');
		
		equ.execute(leftDouble, rightDouble);
		System.out.println("result= ");
		System.out.println(equ.getResult());
	}

	}

