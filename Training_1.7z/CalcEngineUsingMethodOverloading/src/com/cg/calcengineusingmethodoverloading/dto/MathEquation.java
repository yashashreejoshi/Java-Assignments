package com.cg.calcengineusingmethodoverloading.dto;

public class MathEquation {
	
		public MathEquation() {
		
	}
	
		public MathEquation(char opCode) {
		super();
		this.opCode = opCode;
	}
		public MathEquation(char opCode, double leftVals, double rightVals) {
		super();
		this.leftVals = leftVals;
		this.rightVals = rightVals;
		this.opCode = opCode;
	}


			private double leftVals;
			private double rightVals;
			private char opCode;
			private double result;
			
			
			public double getLeftVals() {
				return leftVals;
			}
			public void setLeftVals(double leftVals) {
				this.leftVals = leftVals;
			}
			public double getRightVals() {
				return rightVals;
			}
			public void setRightVals(double rightVals) {
				this.rightVals = rightVals;
			}
			public char getOpCode() {
				return opCode;
			}
			public void setOpCode(char opCode) {
				this.opCode = opCode;
			}
			public double getResult() {
				return result;
			}
			public void setResult(double result) {
				this.result = result;
			}
			
			
			public void execute(double leftVal, double rightVal) {
				this.leftVals=leftVal;
				this.rightVals=rightVal;
				
				execute();
			}
			public void execute() {
				
				switch(opCode) {
				case 'a':
					result = leftVals + rightVals;
					break;
				
				case 's': 
					result = leftVals - rightVals;
					break;
				
				case 'd':
					result = rightVals != 0.0d ? leftVals/rightVals : 0.0d;
					break;
				
				case 'm':
						result = leftVals * rightVals;
						break;
					
				default:
		            System.out.println("invalid opcode");
					result = 0.0d;
					break;
				}
			}
	}
