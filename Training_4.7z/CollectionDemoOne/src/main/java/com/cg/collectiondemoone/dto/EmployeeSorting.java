package com.cg.collectiondemoone.dto;

import java.util.Comparator;
import java.util.Map.Entry;

public class EmployeeSorting implements Comparator<Employee>{

	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return o1.getName().compareToIgnoreCase(o2.getName());
	}

	

	

	
	}





