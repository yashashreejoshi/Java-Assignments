package com.cg.collectiondemoone.ui;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.cg.collectiondemoone.dto.Employee;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Employee emp = new Employee(1006, "A", 9000);
		//Employee empOne = new Employee(1001, "b", 2000);
		//Employee empTwo = new Employee(1003, "c", 1200);
		
		/*Set<Employee> mySet = new TreeSet<Employee>();
		mySet.add(emp);
		mySet.add(empOne);
		mySet.add(empTwo);
		//mySet.add("l");
		//mySet.add("l");
		//mySet.add("k");
		//mySet.add("a");
		
		System.out.println(mySet);*/
		
		Employee emp = new Employee(1001, "A", 200);
		Employee empOne = new Employee(1002, "B", 2000);
		Employee empTwo = new Employee(1002, "B", 2000);
		
		Set<Employee> mySet= new HashSet<Employee>();
		
		mySet.add(emp);
		mySet.add(empOne);
		mySet.add(empTwo);
		//mySet.add("k");
		System.out.println(mySet);
		
		
		
		
		
		
		
		
		
		
		
		
		/*Employee str = new Employee(1001, "A", 4444);
		Employee str1 = new Employee(1001, "A", 4444);
		
		System.out.println(str.hashCode()+ " " +str1.hashCode());
		System.out.println(str.equals(str1));*/

	}

}
