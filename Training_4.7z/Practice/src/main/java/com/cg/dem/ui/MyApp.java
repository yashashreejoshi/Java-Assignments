package com.cg.dem.ui;

import java.util.HashSet;
import java.util.Set;

import com.cg.dem.dto.Employee;

public class MyApp {

	public static void main(String[] args) {
		Employee e1 = new Employee(1,"pooja", "pune", 5200.0);
		Employee e2 = new Employee(2,"pooja", "pune", 7000.0);
		Employee e3 = new Employee(3,"pooja", "pune", 11000.0);
		Employee e4 = new Employee(4,"pooja", "pune", 2000.0);
		
	Set<Employee> mySet= new HashSet<Employee>();
		
		mySet.add(e1);
		mySet.add(e2);
		mySet.add(e3);
		mySet.add(e4);
		//mySet.add("k");
		System.out.println(mySet);

	}

}
