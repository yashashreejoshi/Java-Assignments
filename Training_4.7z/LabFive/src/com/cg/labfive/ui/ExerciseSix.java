package com.cg.labfive.ui;

import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.cg.labfive.dto.EmployeeAge;
import com.cg.labfive.dto.EmployeeAgeException;
import com.cg.labfive.dto.EmployeeException;
import com.cg.labfive.dto.EmployeeName;
import com.cg.labfive.dto.EmployeeNameException;
import com.cg.labfive.dto.Salary;

public class ExerciseSix {
	public static void main(String args[]) throws IOException {
		Scanner in = new Scanner(System.in);
		try {
			//EmployeeName emp = new EmployeeName();
			int n, age;
			//String fname, lname;
			
			//Console c=System.console();
			System.out.println("Enter fname");
			String fname=in.nextLine().trim();
			System.out.println("Enter lname");
			String lname=in.nextLine().trim();
			new EmployeeName().getName(fname, lname);
		}catch(EmployeeNameException e) {
			System.out.println(e.getMessage());
			
		}
		try {
			System.out.println("Enter salary");
			int n=in.nextInt();
			new Salary().getSalary(n);
		}catch(EmployeeException e) {
			System.out.println(e.getMessage());
		}
		try {
			System.out.println("Enter age");
			int age=in.nextInt();
			new EmployeeAge().getAge(age);
		}
			catch(EmployeeAgeException e) {
				System.out.println(e.getMessage());
			}
	}
}
