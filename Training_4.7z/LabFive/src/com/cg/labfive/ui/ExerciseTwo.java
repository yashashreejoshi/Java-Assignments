package com.cg.labfive.ui;

import java.util.Scanner;

public class ExerciseTwo {

	public static void main(String[] args) {
		int n1=1,n2=1,n3; 
		Scanner in = new Scanner(System.in);
		System.out.println("Enter n");
		int count = in.nextInt();
		
		 for(int i=1;i<=count;i++)    
		 {  
		System.out.print(" "+n1);    
		  n3=n1+n2;    
		  n1=n2;    
		  n2=n3;    
		 }    
		
	}

}
