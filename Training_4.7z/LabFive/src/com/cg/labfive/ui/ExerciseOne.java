package com.cg.labfive.ui;

import java.util.Scanner;

public class ExerciseOne {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int ch;
		do {
		System.out.println("1. Red   2.Yellow  3.Green");
		System.out.println("Enter number");
		ch = in.nextInt();
		
		switch (ch) {
		case 1:
			System.out.println("Stop");
			break;
		case 2:
			System.out.println("Ready");
			break;
		case 3:
			System.out.println("Go");
			break;
		}
		}while(ch!=0);

	}

}
