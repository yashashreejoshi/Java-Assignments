package com.cg.labfive.ui;

import java.util.Scanner;

public class ExerciseTwoRecursion {
	
	public void getFibonacci() {
		int n1=1,n2=1,n3; 
		Scanner in = new Scanner(System.in);
		System.out.println("Enter n");
		int count = in.nextInt();
		
		 for(int i=1;i<=count;i++)    
		 {  
		System.out.print(" "+n1);    
		  n3=n1+n2;    
		  n1=n2;    
		  n2=n3;    
		 }    
		getFibonacci();
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExerciseTwoRecursion two = new ExerciseTwoRecursion();
		two.getFibonacci();
		//System.out.println(count);

	}

}
