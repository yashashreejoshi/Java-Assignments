package com.cg.labfive.dto;

public class EmployeeAgeException extends RuntimeException {
	public EmployeeAgeException() {
		super();
	}
	public EmployeeAgeException(String msg) {
		super(msg);
	}
}
