package com.cg.labfive.dto;

public class EmployeeNameException extends RuntimeException {

	public EmployeeNameException() {
		// TODO Auto-generated constructor stub
		super();
	}
	public EmployeeNameException(String msg) {
		super(msg);
	}
}
