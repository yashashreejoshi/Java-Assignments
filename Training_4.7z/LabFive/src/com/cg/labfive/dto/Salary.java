package com.cg.labfive.dto;

public class Salary {
public void getSalary(int salary) {
	if(salary<3000) {
		throw new EmployeeException("salary should be greater than 3000");
	}
	System.out.println(salary);
}
}
