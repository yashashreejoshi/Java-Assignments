package com.cg.labfive.dto;

public class EmployeeName {
	//String fname, lname;
	
	public void getName(String fname, String lname) {
		if(fname.isEmpty() || lname.isEmpty()) {
			throw new EmployeeNameException("first name or last name missing.. pls enter firstname or lastname");
		}
		System.out.println(fname);
		System.out.println(lname);
		
	}

}
