package com.cg.labfive.dto;

public class EmployeeAge {
	public void getAge(int age) {
		if(age<15) {
			throw new EmployeeAgeException("Age should be greater than 15");
		}
		System.out.println(age);
	}

}
