package com.cg.demostatic.ui;

public class MyTest {

	public static void main(String args[]) {
		A.B temp=new A.B();
		temp.getAll();
		
		//A demo = new A();
		//demo.getA();
	}
}

class A {
	private static int a=10;
	static class B {
		int b=20;
		public void getAll() {
			System.out.println("In class b" + a);
		}
	}
	public void getA() {
		System.out.println("In class A");
	}

}
