package com.cg.jpa.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="author")
public class Author {
	public Author() {
		super();
	}
	public Author(int id, String name, int mobile) {
		super();
		this.id = id;
		this.name = name;
		this.mobile = mobile;
	}
	@Id @Column(name="author_id")
	int id;
	@Column(name="author_name")
	String name;
	@Column(name="author_mobile")
	int mobile;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "Author [id=" + id + ", name=" + name + ", mobile=" + mobile + "]";
	}
	
}
