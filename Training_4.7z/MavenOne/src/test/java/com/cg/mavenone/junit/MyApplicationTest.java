package com.cg.mavenone.junit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

//import javax.management.MXBean;

public class MyApplicationTest {

	@Before
	public void beforeTest() {
		System.out.println("before test....");
	}
	@Test
	public void test() {
		System.out.println("Not yet implemented");
	}
	
	@After
	public void afterTest() {
		System.out.println("after test....");
	}

}
