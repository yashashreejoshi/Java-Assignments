package com.cg.mavendemo.ui;

public class Main {

	public static void main(String[] args) {
		System.out.println("HellO Capgemini");
	}

}
