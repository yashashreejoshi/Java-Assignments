package com.cg.multipleinterfacedemo.ui;

public interface ClassFour {
	
	public void setData();
	public void getMyName();

}
