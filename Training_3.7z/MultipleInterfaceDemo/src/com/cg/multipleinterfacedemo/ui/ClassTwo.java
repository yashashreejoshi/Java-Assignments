package com.cg.multipleinterfacedemo.ui;

public interface ClassTwo extends ClassOne {
	public void setData();

}
