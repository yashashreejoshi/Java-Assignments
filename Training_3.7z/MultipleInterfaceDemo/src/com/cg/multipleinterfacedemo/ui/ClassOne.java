package com.cg.multipleinterfacedemo.ui;

public interface ClassOne {
	public void getData();
	public void printAll();
	
	default void getDefaultAll(){
		String name = "Cap";
		System.out.println("Hii");
	}
	
	static void getStaticAll(){
		String name = "Cap";
		System.out.println("hi in A static");
	}

}
