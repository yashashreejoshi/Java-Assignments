package com.cg.multipleinterfacedemo.ui;

public class ClassThree implements ClassOne{

	@Override
	public void getData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printAll() {
		// TODO Auto-generated method stub
		
	}
	
	static void getStaticAll(){
		String name = "Cap";
		System.out.println("hi in  C static");

}

}