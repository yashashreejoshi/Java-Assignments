package com.cg.multipleinterfacedemo.ui;


public class MyApp {

	public static void main(String[] args) {
		ClassOne a = new ClassThree();
		a.getDefaultAll();
		ClassOne.getStaticAll();
		ClassThree c = new ClassThree();
		c.getStaticAll();

	}

}
