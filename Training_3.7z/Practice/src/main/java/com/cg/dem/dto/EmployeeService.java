package com.cg.dem.dto;

import java.util.Comparator;



public class EmployeeService implements Comparator<Employee>{

	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		if( o1.getSalary()> 5000 && o2.getSalary()<10000 ) {
			return 1;
		}else 
		return -1;
			
	}
}
