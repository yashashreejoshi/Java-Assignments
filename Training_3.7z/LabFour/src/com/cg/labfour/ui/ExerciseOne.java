package com.cg.labfour.ui;

public class ExerciseOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
