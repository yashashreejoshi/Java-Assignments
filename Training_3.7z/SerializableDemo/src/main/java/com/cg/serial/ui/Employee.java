package com.cg.serial.ui;

import java.io.Serializable;

public class Employee implements Serializable{
	
	public Employee(int empId, String empname, double empSalary) {
		super();
		this.empId = empId;
		this.empname = empname;
		this.empSalary = empSalary;
	}

	private int empId;
	private String empname;
	private double empSalary;
	
	public Employee()
	{}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empname=" + empname + ", empSalary=" + empSalary + "]";
	}
	
	
}
