package com.cg.serial.ui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp = new Employee(1001, "Pooja", 1000.0);
		try {
			OutputStream fw= new FileOutputStream("D:/object.txt");
			ObjectOutput objwrite= new ObjectOutputStream(fw);
			objwrite.writeObject(emp);
			objwrite.flush();
			objwrite.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		InputStream fr;
		Employee empread=null;
		try {
			fr = new FileInputStream("D:/object.txt");
			ObjectInputStream ois = new ObjectInputStream(fr);
			empread=(Employee) ois.readObject();
			ois.close();
			System.out.println(empread);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
