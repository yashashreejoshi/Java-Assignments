package com.cg.productmanagement.junittest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.service.ProductService;
import com.cg.productmanagement.service.iProductService;

class ProductTest {
	
	iProductService service;
	Product prod;
	@BeforeEach
	public void beforeTest() {
		service = new ProductService();
		prod = new Product();
		prod.setId(1001);
		prod.setName("Mobile");
		prod.setPrice(10000);
		prod.setDescription("nice product");
	}
	
	@Test
	public void myTest() {
		assertNotNull(service.addProduct(prod));
	
	}
	@Test
	public void myTestTwo() {
		assertNotNull(service.showAllProduct());
	}
		
	@AfterEach
	public void afterTest() {
		service = null;
	}

}
