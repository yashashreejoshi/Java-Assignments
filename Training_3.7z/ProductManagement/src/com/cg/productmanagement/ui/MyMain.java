package com.cg.productmanagement.ui;

import java.util.Scanner;

import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.service.ProductService;
import com.cg.productmanagement.service.iProductService;

public class MyMain {

	public static void main(String[] args) {
		printDetails();
		iProductService service = new ProductService();
		Scanner in = new Scanner(System.in);
		int ch=0;
		do {
			Product p = new Product();
			System.out.println("Enter choice");
			ch = in.nextInt();
			switch(ch) {
			case 1:
				System.out.println("Enter prod id");
				int id=in.nextInt();
				System.out.println("Enter prod name");
				String name=in.next();
				System.out.println("Enter prod cost");
				double price = in.nextDouble();
				System.out.println("Enter prod description");
				String description = in.next();
				p.setId(id);
				p.setName(name);
				p.setPrice(price);
				p.setDescription(description);
				service.addProduct(p);
				break;
				
			case 2:
				Product[] allData = service.showAllProduct();
				for(Product product : allData) {
					System.out.println("Prod id" +product.getId());
					System.out.println("Prod name" +product.getName());
					System.out.println("Prod price" +product.getPrice());
					System.out.println("Prod des" +product.getDescription());
				}
				//System.out.println(product);
				break;
			case 3:
				break;
			}
		}while(ch!=0);

		
	}
	public static void printDetails() {
		System.out.println("1.Add 2.Show");
		System.out.println("Exit");
	}

}
