package com.cg.productmanagement.service;

import com.cg.productmanagement.dto.Product;

public interface iProductService {
	
	public Product addProduct(Product prod);
	public Product[] showAllProduct();
}
