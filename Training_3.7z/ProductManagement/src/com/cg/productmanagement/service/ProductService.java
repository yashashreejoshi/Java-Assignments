package com.cg.productmanagement.service;

import com.cg.productmanagement.dao.IProductDao;
import com.cg.productmanagement.dao.ProductDao;
import com.cg.productmanagement.dto.Product;

public class ProductService implements iProductService {
	IProductDao dao;
	
	public ProductService() {
		// TODO Auto-generated constructor stub
		dao=new ProductDao();
	}
	@Override
	public Product addProduct(Product prod) {
		// TODO Auto-generated method stub
		return dao.addProduct(prod);
	}

	@Override
	public Product[] showAllProduct() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

}
