package com.cg.productmanagement.dao;

import com.cg.productmanagement.dto.Product;

public interface IProductDao {
	
	public Product addProduct(Product pro);
	public Product[] showAll();

}
