package com.cg.productmanagement.dao;

import com.cg.productmanagement.dto.Product;

public class ProductDao implements IProductDao{

	Product prod[];
	
	public ProductDao() {
		// TODO Auto-generated constructor stub
		prod = new Product[5];
		int i=0;
	}
	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		for(int i = 0; i<prod.length; i++) {
			prod[i]=new Product();
			prod[i].setId(pro.getId());
			prod[i].setName(pro.getName());
			prod[i].setPrice(pro.getPrice());
			prod[i].setDescription(pro.getDescription());
			i++;
		}
		return pro;
	}

	@Override
	public Product[] showAll() {
		// TODO Auto-generated method stub
		return prod;
	}

}
