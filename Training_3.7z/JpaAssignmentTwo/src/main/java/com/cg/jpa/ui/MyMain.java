package com.cg.jpa.ui;

import java.util.Scanner;

import com.cg.jpa.dto.AuthorService;


public class MyMain {
	public static void print() {
		System.out.println("Add Author");
		System.out.println("Update Author");
		System.out.println("Delete Author");
		System.out.println("Search Author By Author Id");
		
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
	

	
		int ch;
	      AuthorService a = new AuthorService();
	     do {
	    	 print();
	    	 System.out.println("Enter your choice");
	    		ch = in.nextInt();

	    	
	    	 switch(ch) {
	    	 case 1:
	    		 System.out.println("Enter id");
	    		 int id = in.nextInt();
	    		 System.out.println("Enter name");
	    		 String name = in.next();
	    		 System.out.println("Enter mobile number");
	    		 int mobile = in.nextInt();
	    		a.create(id, name, mobile);
	    		 
		       break;
	    	case 2:
	    		
	    		 System.out.println("Enter author id");
	    		 int id1 =in.nextInt();
	    		 System.out.println("Enter author name to update");
	    		 String name1 = in.next();
	    		 System.out.println("Enter author mobile to update");
	    		 int mob = in.nextInt();
	    		 a.update(id1, name1, mob);
	    	break;
	    		
	    		  case 3:
	    		 System.out.println("Enter author id to remove");
	    		 int id2 = in.nextInt();
	    		 a.remove(id2);
	    		 break;
	    		case 4:
	    	
	    		 System.out.println("Enter author id to search");
	    		 int id3 = in.nextInt();
	    		 a.showDetails(id3);
	    	 
	    	 }
	   	
	     }while(ch!=0);

	     }
}
