package com.cg.jpa.dto;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

@Entity
public class Book {

	public Book(int isbn, String title, double price, List<Author> authorList) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.price = price;
		this.authorList = authorList;
	}
	public Book() {
		super();
	}
	
	@Id @Column(name="book_isbn")
	private int isbn;
	@Column(name="book_title")
	private String title;
	@Column(name="book_price")
	private double price;

	private List<Author> authorList = new ArrayList<Author>();
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public List<Author> getAuthorList() {
		return authorList;
	}
	public void setAuthorList(List<Author> authorList) {
		this.authorList = authorList;
	}
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", price=" + price + ", authorList=" + authorList + "]";
	}
	
}
