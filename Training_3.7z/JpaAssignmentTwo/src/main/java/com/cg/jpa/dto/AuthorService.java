package com.cg.jpa.dto;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class AuthorService {

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("authormgmt");  
    EntityManager em=emf.createEntityManager();  
  
    public void create(int id, String name, int mobile) {
		Author aut = new Author(id,name,mobile);
		em.getTransaction().begin();  
		em.persist(aut);
		em.getTransaction().commit();
	}
    
    public void update(int id, String name, int mobile) {
   	 em.getTransaction().begin(); 
   	 Author aut = em.find(Author.class, id);
   	 if(aut!=null) {
   		 aut.setName(name);
   		 aut.setMobile(mobile);
   		 em.persist(aut);
   			em.getTransaction().commit();
   	 }}
       
    
public void remove(int id) {
   	 em.getTransaction().begin(); 
   	 Author remove=em.find(Author.class, id);
		 em.remove(remove);
		 em.getTransaction().commit();
    }
    
  public void showDetails(int id) {
   	 em.getTransaction().begin();
   	 Author show=em.find(Author.class, id);
   	 Author aut = new Author();
   	 System.out.println(show.getId());
   	System.out.println(show.getName());
   	System.out.println(show.getMobile());
   	 
   	 em.getTransaction().commit();
   	 
    }
     
}
