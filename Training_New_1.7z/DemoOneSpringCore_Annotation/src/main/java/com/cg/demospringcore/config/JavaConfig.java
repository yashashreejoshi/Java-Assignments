package com.cg.demospringcore.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.demoonespringcore.dto.Product;
import com.cg.demoonespringcore.dto.Transaction;
import com.cg.demoonespringcore.service.ProductService;
import com.cg.demoonespringcore.service.ProductServiceImpl;

@Configuration
@ComponentScan("com.cg.demoonespringcore")

public class JavaConfig {



/*	@Bean(name="prod", autowire=Autowire.BY_TYPE)
	public Product getProduct() {
		Product pro = new Product();
		pro.setId(1001);
		pro.setName("Sony");
		pro.setPrice(2500);
		pro.setDescription("Good product");
		return pro;
		
	}
	
	//@Autowired
	@Bean(name="tran")
	public Transaction getTransaction() {
		Transaction trans = new Transaction();
		trans.setId(10);
		trans.setAmount(15269.22);
		trans.setDescription("For Product One");
		return trans;*/
		
	//}
}
