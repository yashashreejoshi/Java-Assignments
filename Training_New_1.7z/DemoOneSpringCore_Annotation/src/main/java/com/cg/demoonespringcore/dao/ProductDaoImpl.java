package com.cg.demoonespringcore.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.cg.demoonespringcore.dto.Product;

@Repository("productdao") 
public class ProductDaoImpl implements ProductDao{
	
	
List<Product> productList = new ArrayList<Product>();
	public void save(Product product) {
		// TODO Auto-generated method stub
		productList.add(product);
		
	}

	public List<Product> showAllProduct() {
		// TODO Auto-generated method stub
		return productList;
	}

}
