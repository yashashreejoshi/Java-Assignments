package com.cg.demoonespringcore.ui;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.demoonespringcore.dao.ProductDao;
import com.cg.demoonespringcore.dto.Product;
import com.cg.demoonespringcore.dto.Transaction;
import com.cg.demoonespringcore.service.ProductService;
import com.cg.demospringcore.config.JavaConfig;

@Component
public class MyTest {
	
	@Autowired
	private ProductService d;
	
	static ProductService prodService;
	@PostConstruct
	private void init() {
		prodService=this.d;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext app = new AnnotationConfigApplicationContext(JavaConfig.class);
	
		Product myProduct = (Product) app.getBean("prod");
	
		Transaction myTransaction = (Transaction) app.getBean("tran");
		myProduct.setId(1001);
		myProduct.setName("sony");
		myProduct.setPrice(7800.33);
		myProduct.setDescription("Good Product");
		
		myTransaction.setId(200);
		myTransaction.setAmount(45933.2);
		myTransaction.setDescription("for product 1");
		
		
		
		prodService.addProduct(myProduct);
		System.out.println(prodService.showAllProduct());
	
	}
}
