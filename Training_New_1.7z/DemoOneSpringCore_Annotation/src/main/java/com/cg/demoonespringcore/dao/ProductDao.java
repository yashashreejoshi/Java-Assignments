package com.cg.demoonespringcore.dao;

import java.util.List;

import com.cg.demoonespringcore.dto.Product;

public interface ProductDao {

	public void save(Product product);
	
	public List<Product> showAllProduct();
}
