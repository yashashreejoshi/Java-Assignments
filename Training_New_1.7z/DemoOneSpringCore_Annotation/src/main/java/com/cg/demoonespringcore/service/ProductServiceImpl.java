package com.cg.demoonespringcore.service;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cg.demoonespringcore.dao.ProductDao;
import com.cg.demoonespringcore.dto.Product;


@Service("prodService") 
public class ProductServiceImpl implements ProductService {

	
	@Autowired
 ProductDao productdao;

	

	public void addProduct(Product prod) {
		// TODO Auto-generated method stub
		productdao.save(prod);
		
	}

	public List<Product> showAllProduct() {
		// TODO Auto-generated method stub
		return productdao.showAllProduct();
	}

}
