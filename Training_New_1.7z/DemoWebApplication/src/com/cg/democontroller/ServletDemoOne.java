package com.cg.democontroller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.demowebapplication.dto.Product;
import com.cg.demowebapplication.service.ProductService;
import com.cg.demowebapplication.service.ProductServiceImp;

/**
 * Servlet implementation class ServletDemoOne
 */
@WebServlet(urlPatterns= {"/add","/show","/addproduct","/search", "/searchPro", "/update", "/UpdatePro", "/delete","/DeletePro"})
public class ServletDemoOne extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	ProductService service;
    public ServletDemoOne() {
        super();
        service=new ProductServiceImp() ;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		/*String url=request.getServletPath();
		System.out.println(url);*/
		
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String url=request.getServletPath();
		if(url.equals("/add")) {
			//Addproduct.jsp
			RequestDispatcher req = request.getRequestDispatcher("AddProduct.jsp");
			req.forward(request, response);
		}
		if(url.equals("/show")) {
			//show product,jsp
			List<Product> myList =service.showProduct();
			request.setAttribute("myprod", myList);
			RequestDispatcher req = request.getRequestDispatcher("ShowProduct.jsp");
			req.forward(request, response);
		}
		if(url.equals("/addproduct")) {
	  String productId=request.getParameter("prodId");
	  String productName=request.getParameter("prodName");
	  String productPrice=request.getParameter("prodPrice");
	  String productOnline=request.getParameter("prodOnline");
	  String productCat=request.getParameter("cato");
	  
	  Product prod=new Product();
	  prod.setId(Integer.parseInt(productId));
	  prod.setName(productName);
	  prod.setPrice(Double.parseDouble(productPrice));
	  prod.setOnline(productOnline);
	  prod.setCategory(productCat);
	  service.addProduct(prod);
//	  request.setAttribute("myprod", prod);
	  //PrintWriter out=response.getWriter();
	
	/*  out.println(" Product Id is "+ productId);
	  out.println(" Product Name is "+ productName);
	  out.println(" Product Price is "+ productPrice);
	  out.println(" Product Online is "+ productOnline);
	  out.println(" Product category is "+ productCat);
		*/

	  RequestDispatcher res = request.getRequestDispatcher("product.jsp");
	 
	  res.forward(request, response);
		}
		if(url.equals("/search")) {
			 RequestDispatcher res = request.getRequestDispatcher("SearchProduct.jsp");
			 
			  res.forward(request, response);
		}
		if(url.equals("/searchPro")) {
			String ID = request.getParameter("id");
			int id = Integer.parseInt(ID);
			Product pro = new Product();
			pro=service.searchById(id);
			request.setAttribute("myprod", pro);
			
			 RequestDispatcher resq = request.getRequestDispatcher("SearchProduct.jsp");
			 
			  resq.forward(request, response);
		}
		if(url.equals("/update")) {
			 RequestDispatcher res = request.getRequestDispatcher("Update.jsp");
			 
			  res.forward(request, response);
		}
		
		if(url.equals("/UpdatePro")) {
			
	
			String ID = request.getParameter("proId");
			int id = Integer.parseInt(ID);
			Product pro = new Product();
			pro=service.searchById(id);
			request.setAttribute("myprod", pro);
			String productPrice = request.getParameter("proPrice");
			System.out.println(productPrice);
			pro.setPrice(Double.parseDouble(productPrice));
			 RequestDispatcher resq = request.getRequestDispatcher("Update.jsp");
			 
			  resq.forward(request, response);
			 
		}
		
		if(url.equals("/delete")) {
			 RequestDispatcher res = request.getRequestDispatcher("Delete.jsp");
			 
			  res.forward(request, response);
		}
		
		if(url.equals("/DeletePro")) {

			String ID = request.getParameter("proId");
			int id = Integer.parseInt(ID);
			Product pro = new Product();
			pro=service.searchById(id);
			request.setAttribute("myprod", pro);
			service.delete(pro);
			 RequestDispatcher resq = request.getRequestDispatcher("Delete.jsp");
			 
			  resq.forward(request, response);
		}
	}

}
