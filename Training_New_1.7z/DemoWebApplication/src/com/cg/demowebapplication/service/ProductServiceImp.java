package com.cg.demowebapplication.service;

import java.util.List;

import com.cg.demowebapplication.dao.ProductRepository;
import com.cg.demowebapplication.dao.ProductRepositoryImp;
import com.cg.demowebapplication.dto.Product;

public class ProductServiceImp implements ProductService {
ProductRepository dao;
	public ProductServiceImp(){
		dao=new ProductRepositoryImp(); }
			
	@Override
	public void addProduct(Product prod) {
				// TODO Auto-generated method stub
	dao.save(prod);			
			}

			@Override
			public List<Product> showProduct() {
				// TODO Auto-generated method stub
				return dao.showAll();
			}

			@Override
			public Product searchById(int id) {
				// TODO Auto-generated method stub
				return dao.searchById(id);
			}

			@Override
			public Product update(Product product) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public void delete(Product product) {
				// TODO Auto-generated method stub
			dao.delete(product);
				
			}
		
	}
	


