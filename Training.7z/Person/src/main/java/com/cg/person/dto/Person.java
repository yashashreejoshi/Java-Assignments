package com.cg.person.dto;

public class Person {
	public Person(String name) {
		super();
		this.name = name;
	}

	private String name;
	static int count=0;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + "]";
	}

	@Override
	public int hashCode() {
		System.out.println("Hashcode called");
		//return 10;
		//return name.charAt(0);
		//return name.hashCode();
		return name.length();
	}

	@Override
	public boolean equals(Object obj) {
		count++;
		Person other = (Person) obj;
		System.out.println(count + " time Equals called");
		//System.out.println(count);
		return this.getName().equals(other.getName());
	}

}
