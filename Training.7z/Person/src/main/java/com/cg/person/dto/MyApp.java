package com.cg.person.dto;

import java.util.HashSet;
import java.util.Set;

public class MyApp {

	public static void main(String[] args) {
		Person pOne = new Person("Yashashree");
		Person pTwo = new Person("sonal");
		Person pThree = new Person("tanaya");
		Person pFour = new Person("rutuja");
		//Person pFive = new Person("rutuja");
		Person pFive = new Person("radhika");
		Person pSix = new Person("nikita");
		Person pSeven = new Person("ujjwal");
		Person pEight = new Person("kishor");
		Person pNine = new Person("vijay");
		Person pTen = new Person("adarsh");
		
		Set<Person> mySet = new HashSet<Person>();
		
		mySet.add(pOne);
		mySet.add(pTwo);
		mySet.add(pThree);
		mySet.add(pFour);
		mySet.add(pFive);
		mySet.add(pSix);
		mySet.add(pSeven);
		mySet.add(pEight);
		mySet.add(pNine);
		mySet.add(pTen);

	}

}
