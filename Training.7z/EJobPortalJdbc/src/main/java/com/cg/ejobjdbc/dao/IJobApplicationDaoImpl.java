package com.cg.ejobjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cg.ejobjdbc.dto.JobApplication;
import com.cg.ejobjdbc.exception.EmployeeExe;
import com.cg.ejobjdbc.exception.JobAppliedNotFoundException;
import com.cg.ejobjdbc.util.DbUtil;

public class IJobApplicationDaoImpl implements IJobApplicationDao {

	//inserting job application
	public JobApplication save(JobApplication application) {
		Connection con = DbUtil.getConnection();
		String query_insert="INSERT INTO jobapplication VALUES(?,?,?,?)";
		String query_search="SELECT job_id FROM jobapplication WHERE job_id=?";
		PreparedStatement pstmt=null;
		PreparedStatement pstmtOne=null;
		try {
			pstmt = con.prepareStatement(query_search);
			pstmt.setInt(1, application.getJob().getId());
			ResultSet result = pstmt.executeQuery();
			 
				if(result.next()==false) {
					pstmtOne = con.prepareStatement(query_insert);
					
					pstmtOne.setInt(1, application.getId());
					pstmtOne.setInt(2, application.getJob().getId());
					pstmtOne.setInt(3, application.getSeeker().getId());
					pstmtOne.setDate(4, application.getDate());
					
					pstmtOne.executeUpdate();
				}
				else {
					throw new JobAppliedNotFoundException("APPLIED ALREADY");
				}
			
			//}
		} catch (SQLException e) {
			throw new EmployeeExe("error while inserting records");
		}
		
		
	
		return null;
	}

	
}
