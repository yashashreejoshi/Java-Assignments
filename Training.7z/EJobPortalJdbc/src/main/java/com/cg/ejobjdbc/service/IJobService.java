package com.cg.ejobjdbc.service;

import java.util.List;

import com.cg.ejobjdbc.dto.Job;

public interface IJobService {
	public Job addJob(Job job);
	public List<Job> searchByJobDescription(String description);
	public List<Job> searchByJobCity(String city);
	public Job searchByJobId(int id);
}
