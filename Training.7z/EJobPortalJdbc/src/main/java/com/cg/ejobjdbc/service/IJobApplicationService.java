package com.cg.ejobjdbc.service;

import java.util.List;

import com.cg.ejobjdbc.dto.JobApplication;


public interface IJobApplicationService {
	public JobApplication applyJob(JobApplication application);
}
