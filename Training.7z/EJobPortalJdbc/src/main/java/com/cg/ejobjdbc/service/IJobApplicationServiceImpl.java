package com.cg.ejobjdbc.service;

import java.util.List;

import com.cg.ejobjdbc.dao.IJobApplicationDao;
import com.cg.ejobjdbc.dao.IJobApplicationDaoImpl;
import com.cg.ejobjdbc.dto.JobApplication;

public class IJobApplicationServiceImpl implements IJobApplicationService {
IJobApplicationDao applicationDao;
	public IJobApplicationServiceImpl() {
		applicationDao = new IJobApplicationDaoImpl();
	}
	public JobApplication applyJob(JobApplication application) {
		return applicationDao.save(application);
	}

}
