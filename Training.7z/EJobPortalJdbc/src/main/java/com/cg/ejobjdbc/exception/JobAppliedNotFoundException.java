package com.cg.ejobjdbc.exception;

public class JobAppliedNotFoundException extends RuntimeException {
	public JobAppliedNotFoundException() {
		super();
	}
	
	public JobAppliedNotFoundException(String msg) {
		super(msg);
	}
}
