package com.cg.ejobjdbc.dao;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.math.BigInteger;
import java.security.Provider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.cg.ejobjdbc.dto.Job;
import com.cg.ejobjdbc.dto.JobProvider;
import com.cg.ejobjdbc.dto.JobSeeker;
import com.cg.ejobjdbc.exception.EmployeeExe;
import com.cg.ejobjdbc.exception.JobIdNotFoundException;
import com.cg.ejobjdbc.util.DbUtil;
import com.cg.ejobjdbc.exception.JobNotFoundException;

public class IJobDaoImpl implements IJobDao {

	//inserting job
	public Job save(Job job) {
			Connection con = DbUtil.getConnection();
			String query_insert="INSERT INTO job VALUES(?,?,?,?,?,?)";
			PreparedStatement pstmt=null;
			try {
				pstmt = con.prepareStatement(query_insert);
				pstmt.setInt(1, job.getId());
				pstmt.setString(2, job.getDescription());
				pstmt.setInt(3, job.getVacancies());
				pstmt.setBigDecimal(4, job.getSalary());
				pstmt.setString(5, job.getCity());
				System.out.println(job.getCity());
				pstmt.setInt(6, job.getProvider().getId());
				
				
				pstmt.executeUpdate();
			} catch (SQLException e) {
				throw new EmployeeExe("Error while inserting records");
			}
			
			return null;
	}

	//finding job by job description
	public List<Job> findByDescription(String description) {
		Connection con = DbUtil.getConnection();
		String query_show=("SELECT j.job_id, j.description, j.vacancies, j.salary, j.city, p.provider_id, p.name, p.email FROM Job j INNER JOIN Jobprovider p ON j.provider_id=p.provider_id WHERE j.description=?");

		PreparedStatement pstmt=null;
	
		List<Job> myList=new ArrayList<Job>();
		try {
			pstmt=con.prepareStatement(query_show);
			pstmt.setString(1, description);
			ResultSet result = pstmt.executeQuery();
		
			while(result.next()) {
				Job job = new Job();
				JobProvider provider = new JobProvider();
				job.setId(result.getInt("job_id"));
				job.setDescription(result.getString("description"));
				job.setVacancies(result.getInt("vacancies"));
				job.setSalary(result.getBigDecimal("salary"));
				job.setCity(result.getString("city"));
				provider.setId(result.getInt("provider_id"));
				provider.setName(result.getString("name"));
				provider.setEmail(result.getString("email"));
				job.setProvider(provider);
				
				
				myList.add(job);
			}
		} catch (SQLException e) {
		
			throw new EmployeeExe("Error while fetching records");
		}
		if(myList.isEmpty())
			throw new JobNotFoundException("Jobs u are searching are not available!!!");
			
		return myList;
	} 
	
	//finding job by city name
	public List<Job> findByCity(String city) {
		Connection con = DbUtil.getConnection();
		String query_show=("SELECT j.job_id, j.description, j.vacancies, j.salary, j.city, p.provider_id, p.name, p.email FROM Job j INNER JOIN Jobprovider p ON j.provider_id=p.provider_id WHERE j.city=?");

		PreparedStatement pstmt=null;
		List<Job> myList=new ArrayList<Job>();
		try {
			pstmt=con.prepareStatement(query_show);
			pstmt.setString(1, city);
			ResultSet result = pstmt.executeQuery();
			while(result.next()) {
				Job job = new Job();
				JobProvider provider = new JobProvider();
				job.setId(result.getInt("job_id"));
				job.setDescription(result.getString("description"));
				job.setVacancies(result.getInt("vacancies"));
				job.setSalary(result.getBigDecimal("salary"));
				job.setCity(result.getString("city"));
				provider.setId(result.getInt("provider_id"));
				provider.setName(result.getString("name"));
				provider.setEmail(result.getString("email"));
				job.setProvider(provider);
				
				myList.add(job);
			}
			
		} catch (SQLException e) {
			throw new EmployeeExe("error while fetching records");
		}
	
		if(myList.isEmpty())
			throw new JobNotFoundException("Jobs u are searching are not available!!!");
		return myList;
	}

	//finding jobs by job id
	public Job findById(int id) {
		Connection con = DbUtil.getConnection();
		String query_insert="SELECT j.job_id, j.description, j.vacancies, j.salary, j.city, p.provider_id, p.name, p.email FROM Job j INNER JOIN Jobprovider p ON j.provider_id =p.provider_id WHERE job_id=?";
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		Job job = new Job();
		JobProvider provider = new JobProvider();
		try{
			
			pstmt = con.prepareStatement(query_insert);
			pstmt.setInt(1, id);
			
			rs = pstmt.executeQuery();
			rs.next();
			job.setId(rs.getInt("job_id"));
			job.setDescription(rs.getString("description"));
			job.setVacancies(rs.getInt("vacancies"));
			job.setSalary(rs.getBigDecimal("salary"));
			job.setCity(rs.getString("city"));
			provider.setId(rs.getInt("provider_id"));
			provider.setName(rs.getString("name"));
			provider.setEmail("email");
			job.setProvider(provider);
			
			
		}catch(SQLException e) {
			throw new JobIdNotFoundException("Job ID nOT FOUND");
		}
		

		return job;
	
	}

}
