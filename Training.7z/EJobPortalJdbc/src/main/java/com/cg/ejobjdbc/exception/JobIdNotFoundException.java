package com.cg.ejobjdbc.exception;

public class JobIdNotFoundException extends RuntimeException {
	public JobIdNotFoundException() { }
	public JobIdNotFoundException(String msg) {
		super(msg);
	}
}
