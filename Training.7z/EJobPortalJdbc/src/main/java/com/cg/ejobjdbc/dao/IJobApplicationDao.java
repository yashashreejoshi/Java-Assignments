package com.cg.ejobjdbc.dao;

import java.util.List;

import com.cg.ejobjdbc.dto.JobApplication;



public interface IJobApplicationDao {
	public JobApplication save(JobApplication application);
	
}
