package com.cg.ejobjdbc.dao;

import com.cg.ejobjdbc.dto.JobProvider;
import com.cg.ejobjdbc.dto.JobSeeker;

public interface IJobProviderDao {
	public JobProvider save(JobProvider provider);
	public JobProvider findById(int id);
}
