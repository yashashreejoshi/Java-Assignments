package com.cg.ejobjdbc.dao;

import java.sql.Connection;
import com.cg.ejobjdbc.util.DbUtil;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ejobjdbc.dto.JobProvider;
import com.cg.ejobjdbc.dto.JobSeeker;
import com.cg.ejobjdbc.exception.EmployeeExe;

public class IJobProviderDaoImpl implements IJobProviderDao {

	
	//adding provider
	public JobProvider save(JobProvider provider) {
		Connection con = DbUtil.getConnection();
		String query_insert="INSERT INTO jobprovider VALUES(?,?,?)";
		PreparedStatement pstmt=null;
		try {
			
			pstmt = con.prepareStatement(query_insert);
			pstmt.setInt(1, provider.getId());
			pstmt.setString(2, provider.getName());
			pstmt.setString(3, provider.getEmail());
			
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new EmployeeExe("error while inserting records");
		}
		
		
		return null;
	}

	//finding provider
	public JobProvider findById(int id) {
		Connection con = DbUtil.getConnection();
		String query_insert="SELECT provider_id,name,email FROM jobprovider WHERE provider_id=?";
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		JobProvider p = new JobProvider();
		try{
			
			pstmt = con.prepareStatement(query_insert);
			pstmt.setInt(1, id);
			
			rs = pstmt.executeQuery();
			rs.next();
			p.setId(rs.getInt("provider_id"));
			p.setName(rs.getString("name"));
			p.setEmail(rs.getString("email"));
			
		}catch(SQLException e) {
			throw new EmployeeExe("error while fetching records");
		}
		return p;
	}

}
