package com.cg.ejobjdbc.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.ejobjdbc.dto.JobSeeker;


public class DBUtilJobSeeker {
	public static List<JobSeeker> seekers = new ArrayList<JobSeeker>();

}
