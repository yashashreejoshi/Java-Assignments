package com.cg.ejobjdbc.service;

import com.cg.ejobjdbc.dao.IJobSeekerDao;
import com.cg.ejobjdbc.dao.IJobSeekerDaoImpl;
import com.cg.ejobjdbc.dto.JobSeeker;

public class IJobSeekerServiceImpl implements IJobSeekerService {
	IJobSeekerDao seekerDao;
	public IJobSeekerServiceImpl() {
		seekerDao = new IJobSeekerDaoImpl();
	}

	
	public JobSeeker addSeeker(JobSeeker seeker) {
		return seekerDao.save(seeker);
	}

	public JobSeeker searchBySeekerId(int id) {
		return seekerDao.findById(id);
	}

}
