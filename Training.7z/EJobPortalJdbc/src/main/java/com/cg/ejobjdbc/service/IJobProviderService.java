package com.cg.ejobjdbc.service;

import com.cg.ejobjdbc.dto.JobProvider;

public interface IJobProviderService {
	public JobProvider addProvider(JobProvider provider);
	public JobProvider searchByProviderId(int id);

}
