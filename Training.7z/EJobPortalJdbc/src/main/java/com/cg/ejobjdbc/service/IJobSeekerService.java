package com.cg.ejobjdbc.service;

import com.cg.ejobjdbc.dto.JobSeeker;

public interface IJobSeekerService {
	public JobSeeker addSeeker(JobSeeker seeker);
	public JobSeeker searchBySeekerId(int id);
}
