package com.cg.ejobjdbc.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.ejobjdbc.dao.IJobDao;
import com.cg.ejobjdbc.dao.IJobDaoImpl;
import com.cg.ejobjdbc.dao.IJobSeekerDaoImpl;
import com.cg.ejobjdbc.dto.Job;
import com.cg.ejobjdbc.exception.JobNotFoundException;


public class IJobServiceImpl implements IJobService {
	IJobDao jobDao;
	public IJobServiceImpl() {
		jobDao = new IJobDaoImpl();
	}
	public Job addJob(Job job) {
		return jobDao.save(job);
	}
	public List<Job> searchByJobDescription(String description) {
		return jobDao.findByDescription(description);
	}
	public List<Job> searchByJobCity(String city) {
		return jobDao.findByCity(city);
	}
	public Job searchByJobId(int id) {
		return jobDao.findById(id);
	}
	
}
