package com.cg.ejobjdbc.service;

import com.cg.ejobjdbc.dao.IJobProviderDao;
import com.cg.ejobjdbc.dao.IJobProviderDaoImpl;
import com.cg.ejobjdbc.dto.JobProvider;


public class IJobProviderServiceImpl implements IJobProviderService {

IJobProviderDao providerDao;
	
	public IJobProviderServiceImpl() {
		providerDao = new IJobProviderDaoImpl();
	}

	public JobProvider addProvider(JobProvider provider) {
		return providerDao.save(provider);
	}

	public JobProvider searchByProviderId(int id) {
		return providerDao.findById(id);
	}

}
