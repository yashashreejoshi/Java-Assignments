package com.cg.demostring.ui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.StringTokenizer;

public class MyApp {

	public static void main(String[] args) {
		Reader fread = null;
		Writer fwrite = null;
		BufferedReader bufferr = null;
		BufferedWriter bufferw = null;
		//String data;
		try {
			fread= new FileReader("myread.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 bufferr = new BufferedReader(fread);
		try {
			fwrite = new FileWriter("mywrite.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		bufferw = new BufferedWriter(fwrite);
		String data=null;
		String data2=null;
		try {
			while((data=bufferr.readLine())!=null) {
				StringTokenizer st = new StringTokenizer(data, ":");
				while(st.hasMoreTokens()) {
					data2=st.nextToken();
					System.out.println(data2);
				}
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
