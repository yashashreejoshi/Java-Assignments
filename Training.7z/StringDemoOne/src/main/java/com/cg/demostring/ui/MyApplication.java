package com.cg.demostring.ui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

class A {
	int a;
}
public class MyApplication {
	
	public static void main(String[] args) {
		Reader fread = null;
		Writer fwrite = null;
		BufferedReader bufferr = null;
		BufferedWriter bufferw = null;
		
	try {
		 fread= new FileReader("myread.txt");
		 bufferr = new BufferedReader(fread);
		fwrite = new FileWriter("mywrite.txt");
		bufferw = new BufferedWriter(fwrite);
		String data=null;
		while((data=bufferr.readLine())!=null) {
			//System.out.println(data);
			bufferw.write(data);
			//System.out.println(data);
			//System.out.println(data);
			//char c = (char) data;
			//System.out.println(c);		for printing characters we need to cast them from byte to character
		}
		System.out.println(data);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.println("File not Found");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		System.out.println("file cannot rerad/open");
	}finally 
	{
		try {
			bufferr.close();
			fwrite.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("File not close");
		}
		
	}
	}

}
