package com.cg.inheritance.dto;

public class CargoFlight extends Flight {
	int getSeats() { return 12; }
	
	/*public CargoFlight() { }
	public CargoFlight(int s) {
		seats=s;
	}*/
}
