package com.cg.inheritance.ui;

public class MyTest {

	public static void main(String[] args) {
	A temp = (A)new B();
	((A)temp).getAll();
	System.out.println(temp.a);
	}
}

class B {
	static int a = 10;
	public void getAll() {
		System.out.println("In B....");
	}
	
	
}

class A extends B{
	int a=20;
	public void getAll() {
		System.out.println("In A....");
	}
}