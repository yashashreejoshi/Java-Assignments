package com.cg.inheritance.ui;

public class DayShift extends AbstractEg {

	@Override
	public void login() {
		// TODO Auto-generated method stub
		System.out.println("Hii In Login...");
	}

	@Override
	public double logOut() {
		// TODO Auto-generated method stub
		return 12.4;
	}

}
