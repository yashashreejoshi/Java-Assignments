package com.cg.inheritance.ui;

public abstract class AbstractEg {

	double time = 9.5;
	public abstract void login();
	public abstract double logOut();
	
	public String getCompany() {
		return "Capgemini";
	}

}
