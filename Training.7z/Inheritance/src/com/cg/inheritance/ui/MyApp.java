package com.cg.inheritance.ui;

public class MyApp {

	public static void main(String[] args) {
		AbstractEg temp = new DayShift();
		temp.login();
		temp.logOut();
		temp.getCompany();
		System.out.println(temp.time);

}
}
