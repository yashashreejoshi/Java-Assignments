package com.cg.ejobportal.dao;

import java.nio.file.ProviderNotFoundException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.exception.JobAppliedNotFoundException;
import com.cg.ejobportal.exception.JobIdNotFoundException;
import com.cg.ejobportal.exception.JobNotFoundException;
import com.cg.ejobportal.util.DBUtilApplication;
import com.cg.ejobportal.util.DBUtilJob;
import com.cg.ejobportal.util.DBUtilProvider;

public class IJobDaoImpl implements IJobDao {

	public Job save(Job job) {
		DBUtilJob.jobs.add(job);
		return job;
	}

	public List<Job> findByDescription(String description) {
		List<Job> storeJobs = new ArrayList<Job>();
		for(Job job:DBUtilJob.jobs) {
			if(job.getDescription().equals(description))
				storeJobs.add(job);	
		}
		if(storeJobs.isEmpty())
			throw new JobNotFoundException("Jobs you are searching are not available");
		return storeJobs;
	}

	public List<Job> findByCity(String city) {
		List<Job> storeJobs = new ArrayList<Job>();
		for(Job job:DBUtilJob.jobs) {
			if(job.getCity().equals(city))
				storeJobs.add(job);	
		}
		if(storeJobs.isEmpty())
			throw new JobAppliedNotFoundException("Jobs you are searching are not available");
		return storeJobs;
	}
	
	public Job findById(int id)  {
		for(Job idSearch: DBUtilJob.jobs) {
			if(idSearch.getId()==id) {
				return idSearch;	
			}
			else {
				throw new JobIdNotFoundException("Id not found");
			}
		}
	return null;
	}

	public List<Job> show() {
		return null;
	}
	
	

	

}
