package com.cg.ejobportal.service;

import com.cg.ejobportal.dao.IJobSeekerDao;
import com.cg.ejobportal.dao.IJobSeekerDaoImpl;
import com.cg.ejobportal.dto.JobSeeker;

public class IJobSeekerServiceImpl implements IJobSeekerService{
	IJobSeekerDao seekerDao;
	public IJobSeekerServiceImpl() {
		seekerDao = new IJobSeekerDaoImpl();
	}

	
	public JobSeeker addSeeker(JobSeeker seeker) {
		// TODO Auto-generated method stub
		return seekerDao.save(seeker);
	}

	public JobSeeker searchBySeekerId(int id) {
		// TODO Auto-generated method stub
		return seekerDao.findById(id);
	}

}
