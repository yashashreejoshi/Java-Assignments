package com.cg.ejobportal.service;

import java.util.List;

import com.cg.ejobportal.dao.IJobApplicationDao;
import com.cg.ejobportal.dao.IJobApplicationDaoImpl;
import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobSeeker;

public class IJobApplicationServiceImpl implements IJobApplicationService {
	IJobApplicationDao applicationDao;
	public IJobApplicationServiceImpl() {
		applicationDao = new IJobApplicationDaoImpl();
	}

	
	public List<JobApplication> applyJob(JobApplication application) {
		return applicationDao.save(application);
	}

	public List<JobApplication> searchById(int id) {
		return applicationDao.findById(id);
	}

}
