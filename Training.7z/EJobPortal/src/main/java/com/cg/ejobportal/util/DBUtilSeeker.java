package com.cg.ejobportal.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.ejobportal.dto.JobSeeker;

public class DBUtilSeeker {
	public static List<JobSeeker> seekers = new ArrayList<JobSeeker>();

}
