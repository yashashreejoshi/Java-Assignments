package com.cg.ejobportal.dao;

import java.util.List;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobSeeker;

public interface IJobApplicationDao {
	public List<JobApplication> save(JobApplication application);
	public List<JobApplication> findById(int id);

}
