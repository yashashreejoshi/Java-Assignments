package com.cg.ejobportal.ui;

import java.math.BigDecimal;
	import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
	import java.util.Scanner;

	import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobProvider;
	import com.cg.ejobportal.dto.JobSeeker;
import com.cg.ejobportal.exception.JobAppliedNotFoundException;
import com.cg.ejobportal.exception.JobIdNotFoundException;
import com.cg.ejobportal.exception.JobNotFoundException;
import com.cg.ejobportal.exception.SeekerNotFoundException;
import com.cg.ejobportal.service.IJobApplicationService;
	import com.cg.ejobportal.service.IJobApplicationServiceImpl;
	import com.cg.ejobportal.service.IJobProviderService;
	import com.cg.ejobportal.service.IJobProviderServiceImpl;
	import com.cg.ejobportal.service.IJobSeekerService;
	import com.cg.ejobportal.service.IJobSeekerServiceImpl;
	import com.cg.ejobportal.service.IJobService;
	import com.cg.ejobportal.service.IJobServiceImpl;
import java.math.BigInteger;
import java.util.List;
import java.util.Scanner;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.dto.JobSeeker;
import com.cg.ejobportal.service.IJobApplicationService;
import com.cg.ejobportal.service.IJobApplicationServiceImpl;
import com.cg.ejobportal.service.IJobProviderService;
import com.cg.ejobportal.service.IJobProviderServiceImpl;
import com.cg.ejobportal.service.IJobSeekerService;
import com.cg.ejobportal.service.IJobSeekerServiceImpl;
import com.cg.ejobportal.service.IJobService;
import com.cg.ejobportal.service.IJobServiceImpl;

public class MyApplication {
	
	static IJobService jobService;
	static IJobSeekerService seekerService;
	static IJobProviderService providerService;
	static IJobApplicationService applicationService;

	
	public static void main(String[] args){
		jobService = new IJobServiceImpl();
		providerService = new IJobProviderServiceImpl();
		seekerService = new IJobSeekerServiceImpl();
		applicationService = new IJobApplicationServiceImpl(); 
		JobProvider provider=null;
		JobSeeker seeker=null;
		Job job = null;
		JobApplication application = null;
		Date date;
		Scanner scr = new Scanner(System.in);
		int ch;
		do {
			print();
		ch=scr.nextInt();
		switch(ch) {
		case 1: 
			System.out.println("enter provider id");
			int id= scr.nextInt();
			System.out.println("enter provider name");
			String name= scr.next();
			System.out.println("enter provider email");
			String email= scr.next();
			provider = new JobProvider(id,name,email);
			providerService.addProvider(provider);
			break;
			
		case 2:
			System.out.println("enter job id");
			int jobId= scr.nextInt();
			System.out.println("enter job description");
			String description= scr.next();
			System.out.println("enter job vacancies");
			int vacancies= scr.nextInt();
			System.out.println("enter job salary");
			BigDecimal salary = scr.nextBigDecimal();
			System.out.println("Enter job city");
			String city = scr.next();
			System.out.println("Enter provider name");
			String providerName= scr.next();
			if(providerName.equals(provider.getName()))
				provider.setName(providerName);
			job = new Job(jobId,description,vacancies,salary,city,provider);
			jobService.addJob(job);
			break;
		case 3:
			System.out.println("enter seeker id");
			int seekerId= scr.nextInt();
			System.out.println("enter seeker name");
			String seekerName= scr.next();
			System.out.println("enter seeker email");
			String seekerEmail= scr.next();
			System.out.println("enter seeker contact");
			BigInteger mobile = scr.nextBigInteger();
			System.out.println("Enter seeker qualification");
			String qualification = scr.next();
			System.out.println("Enter seeker city");
			String seekerCity = scr.next();
			seeker = new JobSeeker(seekerId, seekerName, seekerEmail, mobile, qualification, seekerCity);
			seekerService.addSeeker(seeker);
			break;
			
		case 4:
			System.out.println("Enter job description to search");
			String describe= scr.next();
			try {
			List<Job> jobSearch = jobService.searchByJobDescription(describe);
			for(Job allJob: jobSearch) {
				System.out.println(describe+"jobs :");
			System.out.println("Job Id "+allJob.getId());
			System.out.println("Job Description "+ allJob.getDescription());
			System.out.println("Job Vacancies " +allJob.getVacancies());
			System.out.println("Job City "+allJob.getCity());
			System.out.println("Provided By "+allJob.getProvider());
			}
			}catch(JobAppliedNotFoundException e) {
				e.getMessage();
			}
			break; 
		case 5:
			System.out.println("Enter job city to search");
			String location = scr.next();
			try {
			List<Job> searchJob = jobService.searchByJobCity(location);
			for(Job allJob: searchJob) {
				System.out.println(location+"jobs :");
				System.out.println("Job Id "+allJob.getId());
				System.out.println("Job Description "+ allJob.getDescription());
				System.out.println("Job Vacancies " +allJob.getVacancies());
				System.out.println("Job City "+allJob.getCity());
				System.out.println("Provided By "+allJob.getProvider());
				}
			}catch(JobNotFoundException e) {
				e.getMessage();
			}
			break;
		case 6:
			System.out.println("Enter you apply id");
			int apply=scr.nextInt();
			System.out.println("Enter seeker id");
			int seekId = scr.nextInt();
			try {
				seeker = seekerService.searchBySeekerId(seekId);
				}catch(SeekerNotFoundException e) { System.out.println(e.getMessage()); break; } 
			System.out.println("Enter job id");
			int applyId = scr.nextInt();
			try {
				job = jobService.searchByJobId(applyId);
				}catch(JobIdNotFoundException e) { System.out.println(e.getMessage()); break; }
			System.out.println("Enter date in dd/MM/YY");
			
			Date dateTwo = new Date();
			application = new JobApplication(apply,dateTwo,seeker,job);
			List<JobApplication> appliedJobs = applicationService.applyJob(application);
				for(JobApplication j : appliedJobs)
					System.out.println(j);
				break;
		
		}
	}while(ch!=0);
		}
	static void print() {
		System.out.println("1.Add Provider");	
		System.out.println("2.Add Job");
		System.out.println("3.Add Seeker");
		System.out.println("4.Search By Job Description");
		System.out.println("5.Search by Job City");
		System.out.println("6.Apply for Job");
		System.out.println("Enter your choice");
	}
}
