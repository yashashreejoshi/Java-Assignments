package com.cg.ejobportal.exception;

public class JobIdNotFoundException extends RuntimeException {
	public JobIdNotFoundException() { }
	public JobIdNotFoundException(String msg) {
		super(msg);
	}
}
