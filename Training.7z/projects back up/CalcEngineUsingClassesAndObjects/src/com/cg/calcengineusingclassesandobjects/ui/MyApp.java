package com.cg.calcengineusingclassesandobjects.ui;

import com.cg.calcengineusingclassesandobjects.dto.MathEquation;

public class MyApp {
	
	public static MathEquation create(double leftVal, double rightVal, char opCode) {
		MathEquation equation = new MathEquation();
		equation.setLeftVals(leftVal);
		equation.setRightVals(rightVal);
		equation.setOpCode(opCode);
		
		return equation; 	
	}
	public static void main(String[] args) {
		
		MathEquation[] equations = new MathEquation[4];
		equations[0] = create(100.0, 50.0, 'a');
		equations[1] = create(11.0, 5.9, 's');
		equations[2] = create(20.0, 3.0, 'm');
		equations[3] = create(64.0, 8.0, 'd');
		
		for(MathEquation equation : equations) {
			equation.execute();
			System.out.println("results = ");
			System.out.println(equation.getResult());
		}
	}

}
