package com.cg.calcengine.ui;

public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double val1 = 100.0d;
		double val2 = 50.0d;
		double result;
		char opCode = 'd';
		
		if(opCode == 'a') 
			result = val1 + val2;
		
		else if (opCode == 's')
			result = val1 - val2;
		
		else if (opCode == 'd')
			//result = val2 != 0.0d ? val1/val2 : 0.0d;
			result = val1 / val2;
		else if (opCode == 'm')
			result = val1 * val2;
		
		else 
		{
            System.out.println("invalid opcode");
			result = 0.0d;
		}
		
		System.out.println(result);
		
	
	

	}

}
