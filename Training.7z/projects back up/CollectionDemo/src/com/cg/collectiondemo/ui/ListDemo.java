package com.cg.collectiondemo.ui;

import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;

public class ListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List<String> myList = new LinkedList<String>();
		 myList.add("cg");
		 myList.add("pp");
		 myList.add("bbb");
		
		 //List<Integer> myListOne = new LinkedList<Integer>();
		 //myListOne.add("cap");
		/// myListOne.add(1);
		// myListOne.add(false);
		 
		 System.out.println(myList);
		 
		 for(String list: myList) 
			 System.out.println(list);
		 
		 System.out.println("-----------------------------------");
		 Iterator<String> it = myList.iterator();
		 while(it.hasNext()) {
			 System.out.println(it.next());
		 }
	}

}
