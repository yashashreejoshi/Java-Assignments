package com.cg.collectiondemo.ui;

import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		List<String> myList=new ArrayList<>();
		myList.add("C");//0
		myList.add("A");
		myList.add("b");
		myList.add("A");
		//System.out.println(myList.get(2));
		//System.out.println(myList.remove("A"));
		System.out.println(myList.set(3, "o"));
		System.out.println(myList);
	}

}
