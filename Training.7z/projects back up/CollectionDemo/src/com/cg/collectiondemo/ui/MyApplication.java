package com.cg.collectiondemo.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.collectiondemo.dto.Employee;
import com.cg.collectiondemo.exception.EmployeeIdException;
import com.cg.collectiondemo.services.EmployeeService;
import com.cg.collectiondemo.services.EmployeeServiceImpl;

public class MyApplication {
	static EmployeeService service;
	public MyApplication() {
		
	}
	public static void printDetails() {
		System.out.println("1.Add Employee");
		System.out.println("2. Show Employee");
		System.out.println("3.search by name");
		System.out.println("4. update");
		
	}
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		service = new EmployeeServiceImpl();
		int choice=0;
		do {
			printDetails();
			System.out.println("Enter choice");
			choice = in.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter employee id");
				int id =in.nextInt();
				System.out.println("Enter employee name");
				String name =in.next();
				System.out.println("Enter employee salary");
				double salary = in.nextDouble();
				
				Employee emp = new Employee();
				emp.setId(id);
				emp.setName(name);
				emp.setSalary(salary);
				service.addEmployee(emp);
				break;
				
			case 2:
				List<Employee> mylist=service.showAll();
				for(Employee empData : mylist) {
					System.out.println("Id is : "+ empData.getId());
					System.out.println("Name is : "+ empData.getName());
					System.out.println("Salary  is : "+ empData.getSalary());
					System.out.println("-------------------------------------------");
				}
				break;
			case 3:
				System.out.println("Enter the employee to search name");
				String sname=in.next();
				List<Employee> empSearch=service.searchByName(sname);
				for(Employee empAll:empSearch) {
					System.out.println("iD IS" +empAll);
				}
				break;
			case 4:
				System.out.println("Enter id to update");
				int n = in.nextInt();
				System.out.println("Enter salary");
				double sal = in.nextDouble();
				try {
				service.update(n);
				}catch(EmployeeIdException e) {
					System.out.println(e.getMessage());
				}
				break;
			}
		}while(choice!=6);
			
			}
}
