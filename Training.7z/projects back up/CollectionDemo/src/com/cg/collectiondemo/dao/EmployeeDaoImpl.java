package com.cg.collectiondemo.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.collectiondemo.dto.Employee;
import com.cg.collectiondemo.exception.EmployeeIdException;

public class EmployeeDaoImpl implements EmployeeDao{
	
	List<Employee> empData;
	public EmployeeDaoImpl() {
		empData = new ArrayList<Employee>();
	}
	
	public Employee save(Employee emp) {
		empData.add(emp);
		return emp;
	}

	
	@Override
	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		return empData;
	}

	@Override
	public List<Employee> findByName(String name) {
		// TODO Auto-generated method stub
		List<Employee> empSearch = new ArrayList();
		for (Employee employee : empData)
			if(employee.getName().equals(name)){
				empSearch.add(employee);
			}
		return empSearch;
	}

	@Override
	public List<Employee> findById(int id) throws EmployeeIdException {
		// TODO Auto-generated method stub
		List<Employee> empSearch = new ArrayList();
	
		for (Employee employee : empData)
			
			if(employee.getId() == id){
				empSearch.add(employee);
				return empSearch;
			}
			else
			{
				throw new  EmployeeIdException("Id not found...!!!");
			}
		return null;
	}
}
