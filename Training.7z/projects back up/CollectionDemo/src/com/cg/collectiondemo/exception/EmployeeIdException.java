package com.cg.collectiondemo.exception;

public class EmployeeIdException extends RuntimeException{
	public EmployeeIdException() {
		// TODO Auto-generated constructor stub
		super();
	}
	public EmployeeIdException(String msg) {
		super(msg);
	}
}
