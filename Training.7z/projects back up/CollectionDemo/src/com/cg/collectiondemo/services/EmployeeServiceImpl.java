package com.cg.collectiondemo.services;

import java.util.List;

import com.cg.collectiondemo.dao.EmployeeDao;
import com.cg.collectiondemo.dao.EmployeeDaoImpl;
import com.cg.collectiondemo.dto.Employee;
import com.cg.collectiondemo.exception.EmployeeIdException;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao dao;
	public EmployeeServiceImpl() {
		// TODO Auto-generated constructor stub
		dao=new EmployeeDaoImpl();
	}

	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		//emp.getId()
		//emp.setSalary(emp.getSalary()+(emp.getSalary()*0.1));
		dao.save(emp);
		
	}

	@Override
	public List<Employee> searchByName(String name) {
		// TODO Auto-generated method stub
		return dao.findByName(name);
	}

	@Override
	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	@Override
	public Employee update(int id) throws EmployeeIdException{
		// TODO Auto-generated method stub
		List<Employee> emp= dao.findById(id);
		for(Employee empOne : emp) {
			
				empOne.setSalary(empOne.getSalary()+(empOne.getSalary()*0.1));
			
		}
		return null;
	}

	@Override
	public void sort() {
		// TODO Auto-generated method stub
		
	}
	

}
