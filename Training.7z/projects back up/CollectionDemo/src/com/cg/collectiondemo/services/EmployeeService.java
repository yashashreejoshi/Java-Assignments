package com.cg.collectiondemo.services;

import java.util.List;

import com.cg.collectiondemo.dto.Employee;

public interface EmployeeService {

	public void addEmployee(Employee emp);
	public List<Employee> searchByName(String name);
	public List<Employee> showAll();
	public  Employee update(int id);
	public void sort();
}
