package com.cg.collectiondemoone.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.collectiondemoone.dto.Employee;
import com.cg.collectiondemoone.dto.EmployeeSorting;

public class MyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee<Integer, Double> empOne = 
				new Employee<Integer,Double>(1006, " sonal", 999.9);
		Employee<BigInteger, BigDecimal> empTwo = 
				new Employee<BigInteger, BigDecimal>(new BigInteger("1005"), " aish", new BigDecimal(999.9));
		Employee<BigInteger, BigDecimal>empThree = 
				new Employee<BigInteger, BigDecimal>(new BigInteger("1003"), " tana", new BigDecimal(99999.9));
		//List<Employee> myList = new ArrayList<Employee>();
		Employee<Integer, Double> empFour = 
				new Employee<Integer,Double>(100, " ppp", 999.9);
		Employee<Integer, Double> empFive = 
				new Employee<Integer,Double>(10, " lll", 999.9);
		Map<Integer,Employee> myMap = new HashMap<Integer,Employee>();
		
		//Collections.sort(myMap, new EmployeeSorting());
		myMap.put(1,empOne);
		myMap.put(2,empTwo);
		myMap.put(3,empThree);
		myMap.put(4,empFour);
		myMap.put(5,empFive);
		Collection<Employee> myCollection = myMap.values();
		List<Employee> empList = new ArrayList<Employee>(myCollection);
		Collections.sort(empList, new EmployeeSorting());
		
		
		
		for(Employee employee : empList) {
		
		System.out.println(employee.getName());
		
		}

	}

}
