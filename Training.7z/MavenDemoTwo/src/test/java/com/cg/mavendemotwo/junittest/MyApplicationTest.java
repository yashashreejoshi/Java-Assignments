package com.cg.mavendemotwo.junittest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MyApplicationTest {

	@Before
	public void beforeTest() {
		System.out.println("in before");
	}
	@Test
	public void test() {
		System.out.println("in test");
	}
	@After
	public void afterTest() {
		System.out.println("after test");
	}

}
