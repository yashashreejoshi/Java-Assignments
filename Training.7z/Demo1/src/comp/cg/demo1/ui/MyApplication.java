package comp.cg.demo1.ui;

import java.util.Scanner;

import comp.cg.demo1.dto.*;
public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee emp=new Employee();
		//Employee emp1=new Employee();
		Project proj=new Project();
		
		
		Scanner scr = new Scanner(System.in);
		
		
		System.out.println("Enter Employee Id : ");
		int empId = scr.nextInt();
		System.out.println("Enter Employee Name : ");
		String empName = scr.nextLine();
		System.out.println("Enter Employee Salary : ");
		double empSalary = scr.nextDouble();
		System.out.println("Enter Employee dESIGNATION : ");
		String empDeg = scr.next();
		
		System.out.println("Enter Project Id : ");
		int projId = scr.nextInt();
		System.out.println("Enter Project Name : ");
		String projName = scr.next();
		System.out.println("Enter Project Description : ");
		String projDes = scr.next();
		System.out.println("Enter Project Cost : ");
		double projCost = scr.nextDouble();
		
		
		
		
		
		
		
		
		//Project proj1=new Project();
		/*int empId=Integer.parseInt(args[0]);
		String empName=args[1];
		double empSalary=Double.parseDouble(args[2]);   // input by command line arguments 
		String empDeg=args[3]; */
		
		emp.setEmpId(empId);
		emp.setEmpName(empName);
		emp.setEmpSalary(empSalary);
		emp.setEmpDeg(empDeg);
		//emp1.setEmpId(1002);
		//emp1.setEmpName("tANAYA");
		//emp1.setEmpSalary(14000);
		//emp1.setEmpDeg("MANAGER");
		
		/*int projId = Integer.parseInt(args[4]);
		String projName = args[5];
		String projDes = args[6];
		double projCost = Double.parseDouble(args[7]);*/
		
		proj.setProjectId(projId);
		proj.setProjectName(projName);
		proj.setProjectDes(projDes);
		proj.setProjectCost(projCost);
		//proj1.setProjectId(22220);
		//proj1.setProjectName("IOT");
		//proj1.setProjectDes("VB.NET");
		//proj1.setProjectCost(17000.0);
		
		emp.setProj(proj);
	//	emp1.setProj(proj1);
		
		/*System.out.println("id " +emp.getProj().getProjectId());
		System.out.println("name " +emp.getProj().getProjectName());
		System.out.println("des " +emp.getProj().getProjectDes());
		System.out.println("cost " +emp.getProj().getProjectCost());
		*/
		
		System.out.println(emp);
		//System.out.println(emp1);
		
		
		//Project pro = new Project();
		
		//emp.setEmpId(1001);
		//emp.setEmpName("Pooja");
		//emp.setEmpSalary(12000);
		//emp.setEmpDeg("ANALYST");
		
		//System.out.println(emp);
		
		/*
		System.out.println(emp.getEmpId());
		System.out.println(emp.getEmpName());
		System.out.println(emp.getEmpSalary());
		System.out.println(emp.getEmpDeg());
	}
		
		pro.setProjectId(1000);
		pro.setProjectName("Swiggy");
		pro.setProjectDes("Food Delivery App");
		pro.setProjectCost(12000);
		
		
		System.out.println(pro.getProjectId());
		System.out.println(pro.getProjectName());
		System.out.println(pro.getProjectDes());
		System.out.println(pro.getProjectCost());
		
		*/
		}
}
