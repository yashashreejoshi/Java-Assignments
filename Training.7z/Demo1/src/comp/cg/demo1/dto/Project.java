package comp.cg.demo1.dto;

public class Project {
	
	public Project() {
		
	}
	public Project(int projectId, String projectName, String projectDes, double projectCost) {
		super();
		ProjectId = projectId;
		ProjectName = projectName;
		ProjectDes = projectDes;
		ProjectCost = projectCost;
	}

	private int ProjectId; 
	private String ProjectName;            
	private String ProjectDes;          
	private double ProjectCost;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public int getProjectId() {
		return ProjectId;
	}

	public void setProjectId(int projectId) {
		ProjectId = projectId;
	}

	public String getProjectName() {
		return ProjectName;
	}

	public void setProjectName(String projectName) {
		ProjectName = projectName;
	}

	public String getProjectDes() {
		return ProjectDes;
	}
	
	public void setProjectDes(String projectDes) {
		ProjectDes = projectDes;
	}

	public double getProjectCost() {
		return ProjectCost;
	}

	public void setProjectCost(double projectCost) {
		ProjectCost = projectCost;
	}

	@Override
	public String toString() {
		return "Project [ProjectId=" + ProjectId + ", ProjectName=" + ProjectName + ", ProjectDes=" + ProjectDes
				+ ", ProjectCost=" + ProjectCost + "]";
	}

}
