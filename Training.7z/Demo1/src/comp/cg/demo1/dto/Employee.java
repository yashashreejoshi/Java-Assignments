package comp.cg.demo1.dto;

public class Employee {
	
	public Employee() {
		
	}
	public Employee(int empId, String empName, double empSalary, String empDeg, Project proj) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empDeg = empDeg;
		this.proj = proj;
	}
	private int empId; //0
	private String empName;             //null
	private double empSalary;           //0.0
	private String empDeg;   //null
	private Project proj;			//null
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public String getEmpDeg() {
		return empDeg;
	}
	public void setEmpDeg(String empDeg) {
		this.empDeg = empDeg;
	}
	public Project getProj() {
		return proj;
	}
	public void setProj(Project proj) {
		this.proj = proj;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDeg=" + empDeg
				+ ", proj=" + proj + "]";
	}
}
	