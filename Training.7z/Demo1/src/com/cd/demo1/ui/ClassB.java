package com.cd.demo1.ui;

public class ClassB {

	public static void main(String[] args) {
		System.out.println("In main");

	}

}
