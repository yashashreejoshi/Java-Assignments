package com.cg.demo1.ui;

//making class abstract doesn't matter the static block it works by the object
abstract class A {
	static {
		System.out.println("in a ");
	}
}

	class B extends A{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("in main");
		new B();

	}

}
