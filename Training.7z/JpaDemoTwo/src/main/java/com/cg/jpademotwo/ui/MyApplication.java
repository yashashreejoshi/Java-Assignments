package com.cg.jpademotwo.ui;

import java.util.Date;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpademotwo.dto.Employee;
import com.cg.jpademotwo.dto.Project;
import com.cg.jpademotwo.service.EmployeeService;


public class MyApplication {
	public static void print() {
		System.out.println("Add Employee");
		System.out.println("Update Employee");
		System.out.println("Delete Employee");
		System.out.println("Search Employee By Project Id");
		
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
	
		
	//em.getTransaction().begin();  
	
		int ch;
	     // Project proj = new Project();
	      EmployeeService emp1 = new EmployeeService();
	     do {
	    	 print();
	    	 System.out.println("Enter your choice");
	    		ch = in.nextInt();

	    	
	    	 switch(ch) {
	    	 case 1:
	    		 System.out.println("Enter id");
	    		 int id = in.nextInt();
	    		 System.out.println("Enter name");
	    		 String name = in.next();
	    		 System.out.println("Enter salary");
	    		 double sal = in.nextDouble();
	    		 System.out.println("Enter project id");
	    		 int projId = in.nextInt();
	    		 System.out.println("Enter project name");
	    		 String projName = in.next();
	    		emp1.create(id, name, sal, projId, projName);
	    		 
		       break;
	    	 case 2:
	    		
	    		 System.out.println("Enter emp id");
	    		 int id1 =in.nextInt();
	    		 System.out.println("Enter employee name to update");
	    		 String name1 = in.next();
	    		 System.out.println("Enter employee salary to update");
	    		 double sal1 = in.nextDouble();
	    		 System.out.println("Enter project name to update");
	    		 String projName1 = in.next();
	    		 emp1.update(id1, name1, sal1, projName1);
	    			
	    		 
	    		 break;
	    		
	    	 case 3:
	    		 System.out.println("Enter emp id to remove");
	    		 int id2 = in.nextInt();
	    		 emp1.remove(id2);
	    		 break;
	    	 case 4:
	    	
	    		 System.out.println("Enter proj id to search");
	    		 int id3 = in.nextInt();
	    		 emp1.showDetails(id3);
	    	 
	    	 }
	   	 
	     }while(ch!=0);
	    // em.getTransaction().commit();  
	     
	    


	}
	
}
