package com.cg.junitdemo.services;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest {
	Calculator cal;
	@BeforeEach
	public void doBeforeMyTest() {
		cal=new Calculator();
		//System.out.println("in Before test");
	}
	
	@Test()
	public void doMyTest() {
		//System.out.println("in test 1");
		assertEquals(12.0, cal.addNumber(10, 2));
	}
	@Test()
	public void doMyTestOne() {
		//System.out.println("in test 1");
		assertEquals(8.0, cal.subtractNumber(10, 2));
	}
	@Test()
	public void doMyTestTwo() {
		//System.out.println("in test 1");
		assertEquals(20.0, cal.multiplyNumber(10, 2));
	}
	@Test()
	public void doMyTestThree() {
		//System.out.println("in test 1");
		assertEquals(5.0, cal.divideNumber(10, 2));
	}
	
	
		
	@AfterEach
	public void doAfterMyTest() {
		//
		cal=null;
	}
	

}
