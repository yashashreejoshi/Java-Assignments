package com.cg.junitdemo.services;

public class Calculator {
	public double addNumber(double num1, double num2) {
		
		return num1+num2;
		
	}
	public double subtractNumber(double num1, double num2) {
		return num1-num2;
		
	}
	public double multiplyNumber(double num1, double num2) {
		return num1*num2;
	
	}
	public double divideNumber(double num1, double num2) {
		return num1/num2;
		
	}
}
