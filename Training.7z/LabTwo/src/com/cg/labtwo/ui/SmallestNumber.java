package com.cg.labtwo.ui;

import java.util.Scanner;

public class SmallestNumber {
	
	public int secondSmall(int arr[]) {
		
		for(int i = 0; i <arr.length; i++) {
			for(int j = i+1; j <arr.length; j++) {
				if(arr[i]>arr[j]) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
					
				}
			}
			
		}
		return arr[1];
	}

	public static void main(String[] args) {
		SmallestNumber s = new SmallestNumber();
		int arr[], n;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter size of array");
		n=in.nextInt();
		arr = new int[n];
		System.out.println("Enter array elements");
		for(int i =0; i <n; i++) {
			arr[i] = in.nextInt();
		}
		int x = (s.secondSmall(arr));
		System.out.println(x);
		
	}

}
