package com.cg.labtwo.ui;

public class MyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
