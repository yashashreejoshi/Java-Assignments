package com.cg.labtwo.ui;

import java.util.Scanner;

public class ExerciseThree {
	public int getSorted(int a[]) {
		int rev=0;
		for(int i =0; i<a.length;i++) {
			while(a[i] > 0) 
	        { 
	            rev= rev* 10 + a[i] % 10; 
	            a[i] = a[i] / 10; 
	        } 
	        return rev;
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExerciseThree s = new ExerciseThree();
		int arr[], n;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter size of array");
		n=in.nextInt();
		arr = new int[n];
		System.out.println("Enter array elements");
		for(int i =0; i <n; i++) {
		arr[i] = in.nextInt();
		}
	}

}
