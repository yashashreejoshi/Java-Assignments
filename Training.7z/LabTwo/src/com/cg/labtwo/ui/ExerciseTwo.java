package com.cg.labtwo.ui;

import java.util.Arrays;
import java.util.Scanner;

public class ExerciseTwo {
	int i;
	
	public void acceptString(String arr[]) {
		Arrays.sort(arr);
		
		if(arr.length % 2 == 0) {
		for(i=0;i<(arr.length/2);i++) {
			arr[i] = arr[i].toUpperCase();
			System.out.println(arr[i]);
		}
		System.out.println(arr[i]);
	}
		else {
			for(i=0;i<(arr.length/2)+1;i++) {
				arr[i] = arr[i].toUpperCase();
				System.out.println(arr[i]);
			}
			System.out.println(arr);
		}
	}
	public static void main(String[] args) {
		ExerciseTwo e = new ExerciseTwo();
		Scanner in = new Scanner(System.in);
		System.out.println("Enter size of arary");
		int n = in.nextInt();
		String arr[]= new String[n];
		System.out.println("Enter the string");
		for(int i = 0 ; i <arr.length; i++) {
			arr[i]=in.next();
		}
		
		//System.out.println("Hello");
		e.acceptString(arr);
		
	}

}
