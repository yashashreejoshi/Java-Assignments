package com.cg.labtwo.dto;

public class Book {

}
