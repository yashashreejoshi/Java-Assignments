package com.cg.labtwo.dto;

import java.util.Scanner;


public abstract class Item {
	
	public Item() {
		
	}
	public Item(int idNumber, String title, int no_of_copies) {
		super();
		this.idNumber = idNumber;
		this.title = title;
		this.no_of_copies = no_of_copies;
	}
	private int idNumber;
	private String title;
	private int no_of_copies;
	
	public int getIdNumber() {
		return idNumber;
	}
	public void setIdNumber(int idNumber) {
		this.idNumber = idNumber;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getNo_of_copies() {
		return no_of_copies;
	}
	public void setNo_of_copies(int no_of_copies) {
		this.no_of_copies = no_of_copies;
	}
	@Override
	public String toString() {
		return "Item [idNumber=" + idNumber + ", title=" + title + ", no_of_copies=" + no_of_copies + "]";
	}
	
	public void print() {
		System.out.println("\n\t" + idNumber + "\t" +title + "\t" +no_of_copies);
	}
	
	public void addItem() {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter id");
		idNumber = in.nextInt();
		System.out.println("Enter title");
		title = in.next();
		System.out.println("Enter number of copies");
		no_of_copies = in.nextInt();
	}
	
	public void checkIn() {
		//Scanner in = new Scanner(System.in);
		System.out.println("You have checked in the " +title+ "with id number as "+idNumber);
	}
	
	public void checkOut() {
		System.out.println("You have checked out with "+no_of_copies+"copies of " +title+"\t with id_number " +idNumber );
	}
}
