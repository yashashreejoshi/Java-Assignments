package com.cg.labtwo.dto;

public abstract class WrittenItem extends Item{
	public WrittenItem() {
		
	}
	public WrittenItem(String author) {
		super();
		this.author = author;
	}

	private String author;

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "WrittenItem [author=" + author + "]";
	}
}
