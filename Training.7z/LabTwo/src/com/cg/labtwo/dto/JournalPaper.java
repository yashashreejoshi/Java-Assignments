package com.cg.labtwo.dto;

public class JournalPaper {

}
