package com.cg.arraydemo.dto;

import java.util.Scanner;

public class Employee {
	
	public Employee() {
		
	}

	public Employee(int empId, String empName, double empSalary, String empDes) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empDes = empDes;
	}
	private int empId;
	private String empName;
	private double empSalary;
	private String empDes;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public String getEmpDes() {
		return empDes;
	}
	public void setEmpDes(String empDes) {
		this.empDes = empDes;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDes=" + empDes
				+ "]";
	}
	
	public void create () {
		//Employee e = new Employee();
		Scanner in = new Scanner(System.in);
		System.out.println("Enter employee id");
		empId=in.nextInt();
		System.out.println("Enter employee name");
		empName=in.next();
		System.out.println("Enter employee salary");
		empSalary = in.nextDouble();
		System.out.println("Enter employee designation");
		empDes = in.next();
	}
	
	public void display() {
		System.out.println("\n\t" + empId + "\t" +empName + "\t" +empSalary + "\t" +empDes);
	}
	
	
}
