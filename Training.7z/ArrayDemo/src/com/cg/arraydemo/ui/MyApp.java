package com.cg.arraydemo.ui;

import java.util.Scanner;

import com.cg.arraydemo.dto.Employee;

public class MyApp {
	
	

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter number of employess");
		int n = in.nextInt();
		Employee emp [] = new Employee[n];
		int i;
		int ch;
		
		
		 for(i=0;i<n;i++)
             emp[i] =  new Employee();
		do {
			System.out.println("Enter your choice");
			System.out.println("1. Add Employee   2. Show Employee  3. Exit");
			 ch = in.nextInt();
			
			switch(ch) {
			case 1:
				 for(i=0;i<n;i++)
		            {
		                System.out.print("\nEnter details of "+ (i+1) +" Employee\n");
		                emp[i].create();
		            }
				
				break;
			case 2:
				System.out.print("\nDetails of Employees\n");
	            for(i=0;i<n;i++)
	                emp[i].display();
				break;
			case 3:
				System.exit(1);
			}
				
			}while(ch!=0);
			
		
	}

}
