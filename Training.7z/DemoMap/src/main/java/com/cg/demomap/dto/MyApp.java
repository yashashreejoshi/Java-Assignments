package com.cg.demomap.dto;

import java.util.HashMap;
import java.util.Map;

public class MyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,String> myMap = new HashMap<Integer,String>();
		
		myMap.put(10001, "Pooja");
		myMap.put(null, "Sonal");
		myMap.put(null, "Tanaya");
		myMap.put(1, "Tanaya");

		
		System.out.println(myMap);

	}

}
