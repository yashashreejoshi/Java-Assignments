package com.cg.demomap.dto;

public class Employee <T,K> {

	
		
}
