package com.cg.operator.ui;

public class OperatorPrecedence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int val1=21;
		int val2=6;
		int val3=3;
		int val4=1;
		
		int result1 = val1 - val2 / val3;
		int result2 = (val1 - val2) / val3;
		
		System.out.println(result1);
		System.out.println(result2);
		
		int result3 = val1 / val3 * val4 + val2;
		int result4 = val1 / (val3 * (val4 + val2));
		System.out.println(result3);
		System.out.println(result4);


	}

}
