package com.cg.jdbcdemo.ui;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "Capgemini123");
			PreparedStatement pstm=conn.prepareStatement("INSERT INTO EMPLOYEE VALUE(?,?,?)");
			
			pstm.setInt(1, 1001);
			pstm.setString(2, "aBCD");
			pstm.setDouble(3, 1000.11);
			pstm.executeUpdate();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		System.out.println("Driver not loaded");
		}catch(SQLException ex){
			System.out.println("not connected");
		}

	}

}
