package com.cg.demonew.ui;

import java.util.Scanner;

import com.cg.demonew.dto.Account;
import com.cg.demonew.dto.User;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr = new Scanner(System.in);
		User user = new User();
		/*User user1 = new User();
		User user2 = new User();*/
		
		Account acc = new Account();
		/*Account acc1 = new Account();
		Account acc2 = new Account(); */
		int ch;
		do {
			System.out.println("Enter your choice");
			System.out.println("1. Choose   2. Exit");
			 ch = scr.nextInt();
			
			switch(ch) {
			case 1:
				System.out.println("Enter User Id ");
				int userId = scr.nextInt();
				System.out.println("Enter User Name ");
				String userName = scr.next();
				System.out.println("Enter User Address ");
				String userAddress = scr.next();
				System.out.println("Enter Account No ");
				int AccNo = scr.nextInt();
				System.out.println("Enter Account Balance ");
				double accBalance = scr.nextDouble();
				
				user.setUserId(userId);
				user.setUserName(userName);
				user.setUserAddress(userAddress);
				acc.setAccNo(AccNo);
				acc.setAccBalance(accBalance);
				user.setAcc(acc);
				System.out.println(user);
				break;
			case 2:
				System.exit(0);
				//System.out.println("Exit");
				
			}
		}while(ch != 0);
		
		/*user.setUserId(1122);
		user.setUserName("Tanaya");
		user.setUserAddress("Pune");
		
		user1.setUserId(1123);
		user1.setUserName("Tom");
		user1.setUserAddress("tamilnadu");
		
		user2.setUserId(1124);
		user2.setUserName("Jim");
		user2.setUserAddress("Nashik");
		
		acc.setAccNo(111);
		acc.setAccBalance(12000.75);
		
		acc1.setAccNo(222);
		acc1.setAccBalance(2000.05);
		
		acc2.setAccNo(333);
		acc2.setAccBalance(1245.75);
		
		System.out.println("Username" +user.getUserName());
		System.out.println("Account no" +acc.getAccNo());
		System.out.println("balance" +acc.getAccBalance());
		System.out.println("------------------------------------------------------");
		
		System.out.println("Username" +user1.getUserName());
		System.out.println("Account no" +acc1.getAccNo());
		System.out.println("balance" +acc1.getAccBalance());
		System.out.println("-------------------------------------------------------");
		
		System.out.println("Username" +user2.getUserName());
		System.out.println("Account no" +acc2.getAccNo());
		System.out.println("balance" +acc2.getAccBalance());
		System.out.println("-------------------------------------------------------");*/
		
		
		
		

	}

}
