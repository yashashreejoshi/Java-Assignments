package com.cg.demonew.ui;

class A {
		static {
			System.out.println("in a ");
		}
		static int x = 50;
	}

		public class B{
		public static void main(String[] args) throws ClassNotFoundException {
			// TODO Auto-generated method stub
			System.out.println("in main");
			new A();
			A.x=55;
			//Class.forName("com.cg.demonew.ui.A"); //load class without object

		}

	}


