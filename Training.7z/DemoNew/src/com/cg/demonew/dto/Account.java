package com.cg.demonew.dto;

public class Account {
	
	public Account() {
		
	}
	
	public Account(int accNo, double accBalance) {
		super();
		this.accNo = accNo;
		this.accBalance = accBalance;
	}

	private int accNo;
	private double accBalance;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public double getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}

	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", accBalance=" + accBalance + "]";
	}

}
